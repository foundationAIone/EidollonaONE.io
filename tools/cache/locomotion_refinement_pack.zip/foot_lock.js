/**
 * foot_lock.js
 * Keeps a planted foot fixed in world space during the stance window (~0-60% of cycle),
 * with a simple heel-strike → foot-flat → toe-off roll profile.
 */
import * as THREE from 'three';

export class FootLock {
  constructor({ side='L', stanceRatio=0.60 }){
    this.side = side;
    this.stanceRatio = stanceRatio;
    this.isLocked = false;
    this.lockPos = new THREE.Vector3();
    this.lockN = new THREE.Vector3(0,1,0);
    this.footRoll = 0; // -1 heel, +1 toe
    this.phaseTime = 0;
  }

  update({ dt, worldPos, groundN, inStance }){
    if (inStance){
      if (!this.isLocked){
        // Lock on initial contact
        this.isLocked = true;
        this.lockPos.copy(worldPos);
        this.lockN.copy(groundN || new THREE.Vector3(0,1,0));
        this.phaseTime = 0;
      } else {
        this.phaseTime += dt;
      }
      // Heel->Flat->Toe progression over stance
      // early stance heel strike
      this.footRoll = -1 + Math.min(1, (this.phaseTime * 3.0)); // quickly to flat
    } else {
      // Swing phase: unlock and follow predicted position
      this.isLocked = false;
      this.lockPos.lerp(worldPos, Math.min(1, dt * 10.0));
      this.lockN.lerp(groundN || new THREE.Vector3(0,1,0), Math.min(1, dt * 10.0));
      // toe-off roll
      this.footRoll = Math.max(0, 1 - (this.phaseTime * 2.0));
      this.phaseTime = 0;
    }
    return { pos: this.lockPos, n: this.lockN, roll: this.footRoll };
  }
}
