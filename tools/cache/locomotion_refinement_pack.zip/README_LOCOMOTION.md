# Locomotion Refinement Pack
Eliminates "gliding" by coordinating **cadence**, **step length**, **stride warping**, and **foot locks**. Adds **relaxed arm swing** and **catwalk line placement**.

## Files
- `locomotion_engine.js` — main gait coordinator; uses cadence × step length; places feet on a narrow line (catwalk), locks feet during stance (~60%) and calls foot IK.
- `foot_lock.js` — detects stance/swing and keeps the planted foot fixed; adds heel→flat→toe roll.
- `stride_warp.js` — translates the rig the correct distance per frame to reduce sliding.
- `arms_relax_patch.js` — soft arm swing with slight elbow flex and relaxed shoulders.
- `gait_params.json` — defaults you can tune.

## Integrate (avatar_embodiment_viewer.html)

```html
<script type="module">
  import { LocomotionEngine } from "./frontend/components/locomotion_engine.js";
  import { ArmsRelaxPatch } from "./frontend/components/arms_relax_patch.js";

  // after you have: scene, camera, rig, avatar (gltf.scene), ac (orchestrator), ik, ground[]
  const engine = new LocomotionEngine({
    rig, root: avatar, ik, groundMeshes: [ground],
    params: await (await fetch("./frontend/components/gait_params.json")).json()
  });

  // Arm relax overlay
  const arms = new ArmsRelaxPatch({ root: avatar, relax: engine.params.arms_relax });

  // Replace any ad-hoc patrol translation with:
  function locomotion(dt){
    // You can dynamically call engine.setDesiredSpeed(x) based on UI or input
    engine.setDesiredSpeed(1.2); // regal pace
    engine.update(dt);           // moves rig & drives foot IK
    arms.update(dt, engine.phaseL);
  }

  // In your frame loop:
  // locomotion(delta); ac.update(delta); follower.update(delta);
</script>
```

### Tips
- If your IK API differs, adapt LocomotionEngine.update calls where it says `this.ik.solveFoot('L'|'R', pos, normal)`.
- To walk one foot directly in front of the other, keep `step_width_m` small (0.04–0.06 m).
- To avoid sliding, don’t translate the avatar directly; only move the `rig` group. Keep AnimationMixer on the avatar root.
- If you have true walk/run clips, keep them; the engine still helps align speed and foot planting.
