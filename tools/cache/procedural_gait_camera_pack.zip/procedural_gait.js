/**
 * procedural_gait.js
 * Emergency fallback gait generator for rigs with no usable walk/run clips.
 * - Auto-discovers common leg/arm/pelvis bones by regex
 * - Drives a parametric walk cycle based on speed (m/s)
 * - Blends out automatically when AnimationOrchestrator is playing a locomotion clip
 *
 * Assumptions:
 * - Standard biped naming (thigh/upperleg, calf/lowerleg/knee, foot/ankle, arm/forearm/hand, spine/hips/pelvis)
 * - Y-up world
 */

export class ProceduralGait {
  constructor({ root, getSpeed, getIsPlayingClip }) {
    this.root = root; // Avatar (SkinnedMesh parent)
    this.getSpeed = getSpeed || (() => 0);
    this.getIsPlayingClip = getIsPlayingClip || (() => false); // returns true when a walk/run clip is active
    this.time = 0;
    this.enabled = true;
    this.phase = 0; // 0..2π
    this.intensity = 0; // blend 0..1

    this.bones = {
      pelvis: null, spine: null,
      thighL: null, shinL: null, footL: null,
      thighR: null, shinR: null, footR: null,
      upperArmL: null, foreArmL: null, handL: null,
      upperArmR: null, foreArmR: null, handR: null
    };

    this._discover();
  }

  _find(regex) {
    let out = null;
    this.root.traverse(o => { if (o.isBone && regex.test(o.name)) out = o; });
    return out;
  }

  _discover() {
    const rx = (s) => new RegExp(s, 'i');

    // Core
    this.bones.pelvis = this._find(rx('hips|pelvis|root|spine0'));
    this.bones.spine  = this._find(rx('spine(?!.*\\d)|spine1|chest')) || this.bones.pelvis;

    // Legs L
    this.bones.thighL = this._find(rx('thigh.*(l|left)|upper.?leg.*l|hip.*l'));
    this.bones.shinL  = this._find(rx('calf.*l|lower.?leg.*l|shin.*l|knee.*l'));
    this.bones.footL  = this._find(rx('foot.*l|ankle.*l'));
    // Legs R
    this.bones.thighR = this._find(rx('thigh.*(r|right)|upper.?leg.*r|hip.*r'));
    this.bones.shinR  = this._find(rx('calf.*r|lower.?leg.*r|shin.*r|knee.*r'));
    this.bones.footR  = this._find(rx('foot.*r|ankle.*r'));

    // Arms L
    this.bones.upperArmL = this._find(rx('upper.?arm.*l|shoulder.*l|arm.*up.*l'));
    this.bones.foreArmL  = this._find(rx('fore.?arm.*l|lower.?arm.*l'));
    this.bones.handL     = this._find(rx('hand.*l|wrist.*l'));
    // Arms R
    this.bones.upperArmR = this._find(rx('upper.?arm.*r|shoulder.*r|arm.*up.*r'));
    this.bones.foreArmR  = this._find(rx('fore.?arm.*r|lower.?arm.*r'));
    this.bones.handR     = this._find(rx('hand.*r|wrist.*r'));
  }

  update(dt) {
    if (!this.enabled || !this.root) return;
    const speed = this.getSpeed();
    const isClip = this.getIsPlayingClip();

    // When a real locomotion clip is active, blend out the procedural gait
    const targetIntensity = isClip ? 0 : Math.max(0, Math.min(1, speed / 1.6)); // ~walk speed blend
    this.intensity += (targetIntensity - this.intensity) * Math.min(1, dt * 6.0);

    if (this.intensity < 0.01) return;

    // Step frequency ~ 1.6 Hz at 1.3 m/s; scale with speed
    const stepHz = 1.2 + 0.6 * Math.min(1.5, speed / 1.3);
    this.phase += dt * stepHz * Math.PI * 2;
    const s0 = Math.sin(this.phase);
    const c0 = Math.cos(this.phase);

    // Amplitudes (radians/meters)
    const hipFlex = 0.40 * this.intensity;    // leg swing at thigh
    const kneeBend = 0.65 * this.intensity;   // bend during swing
    const anklePitch = 0.25 * this.intensity; // foot roll
    const armSwing = 0.35 * this.intensity;   // opposite arm swing
    const pelvisBob = 0.03 * this.intensity;  // vertical bob (meters)
    const pelvisYaw = 0.08 * this.intensity;  // yaw oscillation
    const spineCounter = 0.06 * this.intensity;

    const applyLeg = (thigh, shin, foot, phaseSign) => {
      if (!thigh || !shin) return;
      const s = Math.sin(this.phase * phaseSign);
      const c = Math.cos(this.phase * phaseSign);
      thigh.rotation.x = hipFlex * s;      // forward/back swing
      shin.rotation.x  = Math.max(0, kneeBend * Math.max(0, -s)); // bend on forward swing
      if (foot) foot.rotation.x = anklePitch * (-s * 0.5 + c * 0.5);
    };

    const applyArm = (upper, fore, phaseSign) => {
      if (!upper) return;
      const s = Math.sin(this.phase * phaseSign);
      upper.rotation.x = armSwing * (-s); // opposite to leg
      if (fore) fore.rotation.x = armSwing * Math.max(0, s * 0.6);
    };

    // Pelvis bob/yaw
    if (this.bones.pelvis) {
      this.bones.pelvis.position.y = pelvisBob * (1 - c0*c0); // smooth bounce
      this.bones.pelvis.rotation.y = pelvisYaw * s0;
    }
    if (this.bones.spine) {
      this.bones.spine.rotation.y = -spineCounter * s0; // counter-rotation
    }

    // Legs: L uses +phase, R uses -phase
    applyLeg(this.bones.thighL, this.bones.shinL, this.bones.footL, +1);
    applyLeg(this.bones.thighR, this.bones.shinR, this.bones.footR, -1);

    // Arms swing opposite to legs
    applyArm(this.bones.upperArmL, this.bones.foreArmL, -1);
    applyArm(this.bones.upperArmR, this.bones.foreArmR, +1);
  }
}
