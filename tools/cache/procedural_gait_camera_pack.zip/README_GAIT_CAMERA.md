# Procedural Gait + Camera Follower

Use these when:
- The avatar has no working walk/run clips or they are not found → ProceduralGait makes limbs move.
- The screen appears to "zoom" rather than the avatar moving → CameraFollower anchors the camera to the rig so motion is undeniable.

## Setup (vanilla Three.js)

```js
import { ProceduralGait } from '/frontend/components/procedural_gait.js';
import { CameraFollower } from '/frontend/components/camera_follower.js';

// After GLTF load
const rig = new THREE.Group();
rig.name = 'AvatarRigRoot';
rig.add(gltf.scene);          // keep skeleton intact
scene.add(rig);

// Mixer targets the avatar skeleton root (gltf.scene), not the rig
const mixer = new THREE.AnimationMixer(gltf.scene);

// Speed accessor updated by your locomotion (patrol/click-to-move)
let currentSpeed = 0;
const getSpeed = () => currentSpeed;
const getIsPlayingClip = () => Boolean(/* your walk/run action is active */);

const gait = new ProceduralGait({ root: gltf.scene, getSpeed, getIsPlayingClip });
const follower = new CameraFollower({ camera, controls, rig, offset: {x:0, y:1.7, z:4.0} });

function animate(dt){
  // ... your locomotion controller sets currentSpeed (m/s) and moves rig
  gait.update(dt);
  follower.update(dt);
  mixer.update(dt);
}
```

## Tips

- If knees bend the wrong way, invert shin.rotation.x logic in ProceduralGait.
- Adjust follower offset to taste; optionally set controls.enableZoom = false.
- Once proper walk clips are mapped, ProceduralGait will auto-fade out.
