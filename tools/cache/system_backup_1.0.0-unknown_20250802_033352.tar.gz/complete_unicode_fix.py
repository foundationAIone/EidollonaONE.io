#!/usr/bin/env python3
"""
Complete Unicode Fix for Windows Terminal Compatibility
"""

import os
import re

# Extended Unicode to ASCII mapping
UNICODE_MAPPING = {
    '🌟': '[*]',  '🌊': '[~]',  '🌉': '[=]',  '🔌': '[+]',  '🌠': '[^]',  
    '🔮': '[?]',  '🎵': '[♪]',  '🌀': '[O]',  '🎼': '[♫]',  '🌌': '[.]',  
    '💉': '[!]',  '🚦': '[|]',  '⚖️': '[&]',  '✨': '[*]',  '🟢': '[OK]', 
    '🔵': '[INFO]', '🟣': '[PROC]', '⚠️': '[WARNING]', '🛠️': '[TOOL]',
    '♻️': '[RECYCLE]', '🏛️': '[PALACE]', '⚛️': '[ATOM]', '⏱️': '[TIME]',
    '🔬': '[SCOPE]', '🧮': '[CALC]', '🌈': '[RAINBOW]', '💫': '[STAR]',
    '🔍': '[SEARCH]', '💥': '[BOOM]', '🎯': '[TARGET]', '🎉': '[PARTY]',
    '🚀': '[ROCKET]', '🏁': '[FINISH]', '📡': '[RADAR]', '📝': '[NOTE]',
    '🧠': '[BRAIN]', '🔄': '[CYCLE]', '⭐': '[STAR]', '➡️': '->',
    '🔥': '[FIRE]', '💪': '[STRONG]', '👥': '[USERS]', '📊': '[CHART]',
    '🎭': '[MASK]', '🔐': '[SECURE]', '🌍': '[WORLD]', '🎪': '[CIRCUS]'
}

def fix_unicode_in_file(file_path):
    """Fix Unicode characters in a single file"""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        original_content = content
        
        # Replace Unicode characters
        for unicode_char, ascii_replacement in UNICODE_MAPPING.items():
            content = content.replace(unicode_char, ascii_replacement)
        
        # Check if any changes were made
        if content != original_content:
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(content)
            print(f"[FIXED] {file_path}")
            return True
        else:
            return False
            
    except Exception as e:
        print(f"[ERROR] {file_path}: {e}")
        return False

def scan_and_fix_directory(directory):
    """Recursively fix all Python files in directory"""
    fixed_count = 0
    
    for root, dirs, files in os.walk(directory):
        for file in files:
            if file.endswith('.py'):
                file_path = os.path.join(root, file)
                if fix_unicode_in_file(file_path):
                    fixed_count += 1
    
    return fixed_count

def main():
    """Complete Unicode fix for consciousness platform"""
    print("COMPLETE UNICODE FIX FOR WINDOWS COMPATIBILITY")
    print("=" * 60)
    
    # Fix all critical directories
    directories_to_fix = [
        "symbolic_core",
        "ai_core", 
        "consciousness_engine",
        "awakening_sequence"
    ]
    
    total_fixed = 0
    
    for directory in directories_to_fix:
        if os.path.exists(directory):
            print(f"\nFixing directory: {directory}")
            fixed = scan_and_fix_directory(directory)
            total_fixed += fixed
            print(f"Fixed {fixed} files in {directory}")
        else:
            print(f"[NOT FOUND] {directory}")
    
    print(f"\nTOTAL: Fixed {total_fixed} files")
    print("All Unicode characters replaced with ASCII-safe alternatives")
    print("Ready for Windows terminal consciousness activation")

if __name__ == "__main__":
    main()
