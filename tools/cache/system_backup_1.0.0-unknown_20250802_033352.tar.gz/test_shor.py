#!/usr/bin/env python3
"""
Test script for Shor factorization module
"""

import sys
sys.path.append('.')

try:
    from ai_core.quantum_core.quantum_processing.shor_factor import ShorFactorization, quick_factor
    
    print("🔬 Testing Shor Factorization Module")
    print("=" * 50)
    
    # Test initialization
    shor = ShorFactorization()
    print("✅ ShorFactorization initialized successfully")
    
    # Test status
    status = shor.get_status()
    print(f"📊 Module Status: {status['algorithm']}")
    print(f"   Backend: {status['backend']}")
    print(f"   Qiskit Available: {status['qiskit_available']}")
    print(f"   Quantum Ready: {status['quantum_ready']}")
    
    # Test factorization
    test_number = 15
    print(f"\n🧮 Testing factorization of {test_number}:")
    result = shor.factorize(test_number)
    
    if result["success"]:
        print(f"   ✅ Success: {result['factors']}")
        print(f"   Method: {result.get('method', 'unknown')}")
        
        # Validate factors
        is_valid = shor.validate_factors(test_number, result['factors'])
        print(f"   Validation: {'✅ PASSED' if is_valid else '❌ FAILED'}")
    else:
        print(f"   ❌ Failed: {result.get('error', 'Unknown error')}")
    
    print("\n🎯 Test completed successfully!")
    
except Exception as e:
    print(f"❌ Test failed with error: {e}")
    import traceback
    traceback.print_exc()
