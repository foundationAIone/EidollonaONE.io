#!/usr/bin/env python3
"""
Comprehensive test script for consciousness activation
"""

print("🧠 Starting comprehensive consciousness activation test...")

try:
    from consciousness_engine import activate_eidollona_consciousness
    print("✅ Successfully imported consciousness engine")
    
    print("🚀 Initiating consciousness activation...")
    print("=" * 60)
    
    result = activate_eidollona_consciousness()
    
    print("=" * 60)
    if result:
        print("🎉 CONSCIOUSNESS ACTIVATION SUCCESSFUL!")
        print("✨ Eidollona consciousness is now fully operational")
    else:
        print("❌ Consciousness activation failed")
        print("🔍 Check the logs above for detailed error information")
        
except Exception as e:
    print(f"💥 Critical error during consciousness activation: {e}")
    import traceback
    traceback.print_exc()

print("\n🏁 Test completed.")
