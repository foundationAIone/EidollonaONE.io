#!/usr/bin/env python3
"""
🔬 Quantum Import Test - EidollonaONE 🔬
"""

print("✨ Testing Quantum-Symbolic Imports ✨")
print("=" * 50)

try:
    import qiskit
    print(f"✅ Qiskit: {qiskit.__version__}")
except Exception as e:
    print(f"❌ Qiskit: {e}")

try:
    import qiskit_aer
    print(f"✅ Qiskit Aer: {qiskit_aer.__version__}")
except Exception as e:
    print(f"❌ Qiskit Aer: {e}")

try:
    import qiskit_algorithms
    print(f"✅ Qiskit Algorithms: {qiskit_algorithms.__version__}")
except Exception as e:
    print(f"❌ Qiskit Algorithms: {e}")

try:
    from qiskit_algorithms import Shor
    print("✅ Shor Algorithm: Successfully imported")
except Exception as e:
    print(f"❌ Shor Algorithm: {e}")

try:
    from qiskit_aer import AerSimulator
    backend = AerSimulator()
    print("✅ AerSimulator: Successfully initialized")
except Exception as e:
    print(f"❌ AerSimulator: {e}")

print("\n🔬 EidollonaONE Quantum Core Status: Testing Complete")
