"""
🧪 Test Script - Verify RPM Ecosystem Imports
Tests that all imports work correctly for the symbolic optimizer
"""

import sys
from pathlib import Path

# Add avatar system to path
avatar_path = Path(__file__).parent / "avatar"
if str(avatar_path) not in sys.path:
    sys.path.insert(0, str(avatar_path))

def test_rpm_ecosystem_imports():
    """Test all RPM ecosystem imports"""
    print("🧪 Testing RPM Ecosystem Imports")
    print("=" * 40)
    
    # Test basic package import
    try:
        import rpm_ecosystem
        print("✅ rpm_ecosystem imported successfully")
    except ImportError as e:
        print(f"❌ Failed to import rpm_ecosystem: {e}")
        return False
    
    # Test EcosystemManager import
    try:
        from rpm_ecosystem import EcosystemManager
        print("✅ EcosystemManager imported successfully")
    except ImportError as e:
        print(f"❌ Failed to import EcosystemManager: {e}")
    
    # Test AvatarConfig import
    try:
        from rpm_ecosystem import AvatarConfig
        print("✅ AvatarConfig imported successfully")
    except ImportError as e:
        print(f"❌ Failed to import AvatarConfig: {e}")
    
    # Test AvatarCustomizationParams import
    try:
        from rpm_ecosystem import AvatarCustomizationParams
        print("✅ AvatarCustomizationParams imported successfully")
    except ImportError as e:
        print(f"❌ Failed to import AvatarCustomizationParams: {e}")
    
    # Test direct imports (as used in symbolic_optimizer)
    try:
        from rpm_ecosystem.ecosystem_manager import EcosystemManager, AvatarConfig
        print("✅ Direct EcosystemManager and AvatarConfig imports successful")
    except ImportError as e:
        print(f"❌ Failed direct import: {e}")
    
    try:
        from rpm_ecosystem.avatar_generation.character_customizer import AvatarCustomizationParams
        print("✅ Direct AvatarCustomizationParams import successful")
    except ImportError as e:
        print(f"❌ Failed direct AvatarCustomizationParams import: {e}")
    
    # Test system initialization
    try:
        from rpm_ecosystem import initialize_sovereign_avatar_system, get_available_modules
        
        available_modules = get_available_modules()
        print(f"\n📦 Available Modules: {len(available_modules)}")
        for module in available_modules:
            print(f"   - {module}")
        
        # Try to initialize system
        system = initialize_sovereign_avatar_system()
        if system:
            print("\n✅ System initialized successfully!")
            print(f"   System type: {type(system).__name__}")
        else:
            print("\n⚠️ System initialization returned None")
            
    except Exception as e:
        print(f"❌ System test failed: {e}")
    
    print("\n🎯 Import test completed!")
    return True

if __name__ == "__main__":
    test_rpm_ecosystem_imports()
