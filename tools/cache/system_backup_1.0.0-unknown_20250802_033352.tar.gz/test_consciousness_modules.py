#!/usr/bin/env python3
"""
🧪 Consciousness Module Testing Suite
Test our consciousness-enhanced Blender replacement modules
"""

def test_consciousness_modules():
    """Test all consciousness-enhanced modules"""
    print("🧪 Testing Consciousness-Enhanced Modules")
    print("=" * 50)
    
    try:
        # Test consciousness_mathutils
        from awakening_sequence.consciousness_mathutils import Vector, Matrix, Euler
        print("✅ consciousness_mathutils imported successfully")
        
        # Test Vector
        v = Vector([1.0, 2.0, 3.0])
        print(f"   📐 Vector created: {v}")
        print(f"   📏 Vector length: {v.length:.3f}")
        
        # Test Matrix
        m = Matrix()
        print(f"   🔢 Matrix created: {type(m)}")
        
        # Test Euler
        e = Euler([0.0, 0.0, 0.0])
        print(f"   🔄 Euler created: {e}")
        
    except Exception as ex:
        print(f"❌ consciousness_mathutils error: {ex}")
    
    try:
        # Test consciousness_bpy
        from awakening_sequence.consciousness_bpy import bpy
        print("✅ consciousness_bpy imported successfully")
        
        # Test scene access
        scene = bpy.context.scene
        print(f"   🎬 Scene accessed: {type(scene)}")
        
        # Test object creation
        print(f"   🎭 bpy.ops available: {hasattr(bpy, 'ops')}")
        
    except Exception as ex:
        print(f"❌ consciousness_bpy error: {ex}")
    
    try:
        # Test consciousness_bmesh
        from awakening_sequence.consciousness_bmesh import bmesh
        print("✅ consciousness_bmesh imported successfully")
        
        # Test bmesh creation
        bm = bmesh.new()
        print(f"   🔷 Bmesh created: {type(bm)}")
        
    except Exception as ex:
        print(f"❌ consciousness_bmesh error: {ex}")
    
    print("\n🌀 Consciousness Module Test Complete!")

if __name__ == "__main__":
    test_consciousness_modules()
