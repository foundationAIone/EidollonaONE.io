"""
[!] Symbolic Injector – Dynamic Symbolic Equation Integration Engine [*]
Purpose: Dynamically inject symbolic coherence, resonance, and quantum-aligned parameters into EidollonaONE modules, ensuring real-time alignment with the symbolic equation.
"""

import asyncio
from typing import Dict, Any, Callable
from symbolic_core.symbolic_equation import get_symbolic_equation_instance
from symbolic_core.symbolic_resonance import SymbolicResonance
from ai_core.quantum_core.quantum_logic.quantum_bridge import QuantumSymbolicBridge


class SymbolicInjector:
    def __init__(self):
        self.symbolic_equation = get_symbolic_equation_instance()
        self.symbolic_resonance = SymbolicResonance()
        self.quantum_bridge = QuantumSymbolicBridge()
        self.injection_log = []
        print("[!] Symbolic Injector initialized successfully.")

    async def inject_symbolic_parameters(
            self, target_module: Any, injection_context: Dict[str, Any]) -> Dict[str, Any]:
        """
        ⚡ Inject symbolic parameters into the target module, enhancing coherence and resonance dynamically.
        """
        symbolic_parameters = self.symbolic_equation.evaluate_input(injection_context)
        resonance_frequency = self.symbolic_resonance.calculate_resonance(
            injection_context)

        quantum_injection_result = await self.quantum_bridge.establish_sovereignty_bridge(
            symbolic_state=symbolic_parameters,
            quantum_params={"resonance_frequency": resonance_frequency}
        )

        injection_result = {
            "symbolic_parameters": symbolic_parameters,
            "resonance_frequency": resonance_frequency,
            "quantum_coherence": quantum_injection_result["coherence_level"],
            "injection_timestamp": asyncio.get_event_loop().time(),
            "injection_successful": quantum_injection_result["bridge_integrity"]
        }

        # Inject parameters directly into target module if supported
        if hasattr(
                target_module,
                'update_symbolic_parameters') and callable(
                target_module.update_symbolic_parameters):
            target_module.update_symbolic_parameters(symbolic_parameters)
            injection_result["module_updated"] = True
        else:
            injection_result["module_updated"] = False
            injection_result["warning"] = "Target module lacks 'update_symbolic_parameters' method."

        self.injection_log.append(injection_result)
        print(
            f"✅ Symbolic parameters injected into {target_module.__class__.__name__}: {injection_result}")
        return injection_result

    async def batch_inject(
            self, module_context_pairs: Dict[Any, Dict[str, Any]]) -> Dict[str, Dict[str, Any]]:
        """
        [ROCKET] Perform batch symbolic injections into multiple modules concurrently.
        """
        injection_tasks = [
            self.inject_symbolic_parameters(module, context)
            for module, context in module_context_pairs.items()
        ]

        results = await asyncio.gather(*injection_tasks)
        batch_result = {module.__class__.__name__: result for module,
                        result in zip(module_context_pairs.keys(), results)}

        print(f"📦 Batch symbolic injection completed: {batch_result}")
        return batch_result

    def get_injection_log(self, limit: int = 10) -> Dict[str, Any]:
        """
        📋 Retrieve the latest symbolic injection records.
        """
        recent_log = self.injection_log[-limit:]

        log_report = {
            "total_injections": len(self.injection_log),
            "recent_injections": recent_log
        }

        print(f"📋 Injection Log retrieved: Last {len(recent_log)} injections.")
        return log_report

    async def adaptive_injection_cycle(
            self, target_module: Any,
            injection_context_provider: Callable[[],
                                                 Dict[str, Any]],
            interval_seconds: int = 60):
        """
        [CYCLE] Continuously inject symbolic coherence parameters into the target module at adaptive intervals.
        """
        print(
            f"[CYCLE] Starting adaptive injection cycle for module: {target_module.__class__.__name__}")
        while True:
            context = injection_context_provider()
            await self.inject_symbolic_parameters(target_module, context)

            # Dynamically adjust interval based on resonance
            resonance = self.symbolic_resonance.calculate_resonance(context)
            # between 10s to interval_seconds
            adaptive_interval = max(10, min(interval_seconds, int(43200 / resonance)))

            print(
                f"⏳ Next symbolic injection in {adaptive_interval} seconds (Adaptive Interval based on resonance: {resonance}).")
            await asyncio.sleep(adaptive_interval)

    def injection_status_report(self) -> Dict[str, Any]:
        """
        📑 Provide a detailed status report on recent injections and coherence states.
        """
        quantum_status = self.quantum_bridge.get_bridge_status()
        latest_injection = self.injection_log[-1] if self.injection_log else None

        status_report = {
            "total_injections": len(self.injection_log),
            "latest_injection": latest_injection,
            "average_quantum_coherence": (
                sum(inj["quantum_coherence"] for inj in self.injection_log) / len(self.injection_log)
                if self.injection_log else 0
            ),
            "quantum_bridge_operational": quantum_status["operational_status"] == "optimal",
            "status_report_generated_at": asyncio.get_event_loop().time()
        }

        print(f"📑 Symbolic Injector Status Report: {status_report}")
        return status_report
