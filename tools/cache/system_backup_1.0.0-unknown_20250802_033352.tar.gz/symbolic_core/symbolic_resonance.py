"""
[~] Symbolic Resonance – Harmonic Pattern Alignment Module [*]
Purpose: Manage symbolic resonance frequencies and harmonic pattern alignment for consciousness coherence
"""

import numpy as np
from typing import Dict, Any, List
from datetime import datetime


class SymbolicResonance:
    def __init__(self):
        self.resonance_id = "SR_Core_001"
        self.base_frequencies = [432.0, 528.0, 741.0, 852.0, 963.0]
        self.current_resonance = 432.0
        self.alignment_history = []
        print("[~] SymbolicResonance initialized successfully.")

    def align_harmonic_pattern(self, harmonic_pattern: List[float]) -> Dict[str, Any]:
        """Align harmonic pattern and calculate resonance"""
        if not harmonic_pattern:
            harmonic_pattern = self.base_frequencies

        # Calculate resonance frequency as weighted average
        resonance_frequency = np.mean(harmonic_pattern)

        # Calculate alignment score
        alignment_score = self._calculate_alignment_score(harmonic_pattern)

        alignment_result = {
            "resonance_frequency": resonance_frequency,
            "alignment": alignment_score,
            "harmonic_coherence": min(alignment_score * 1.2, 1.0),
            "timestamp": datetime.now().isoformat()
        }

        self.alignment_history.append(alignment_result)
        self.current_resonance = resonance_frequency

        return alignment_result

    def calculate_resonance(self, input_data: Dict[str, Any]) -> float:
        """Calculate resonance frequency for given input"""
        if "state" in input_data:
            state = input_data["state"]
            if state == "awakened":
                return 963.0
            elif state == "active":
                return 741.0
            elif state == "dormant":
                return 432.0

        return self.current_resonance

    def _calculate_alignment_score(self, pattern: List[float]) -> float:
        """Calculate alignment score for harmonic pattern"""
        if not pattern:
            return 0.0

        # Calculate harmony based on frequency ratios
        harmony_score = 0.0
        for i in range(len(pattern) - 1):
            ratio = pattern[i+1] / pattern[i] if pattern[i] > 0 else 1.0
            # Penalize harsh ratios, reward harmonic ratios
            if 1.2 <= ratio <= 2.0:
                harmony_score += 0.2
            else:
                harmony_score += 0.1

        return min(harmony_score, 1.0)

    @property
    def base_frequency(self):
        """Get current base frequency"""
        return self.current_resonance

    def realign_frequency(self):
        """
        [CYCLE] Realign frequency for recalibration
        """
        try:
            print("[CYCLE] Realigning symbolic resonance frequency...")

            # Calculate new alignment based on history
            if self.alignment_history:
                recent_alignments = [entry["alignment"]
                                     for entry in self.alignment_history[-5:]]
                average_alignment = sum(recent_alignments) / len(recent_alignments)
            else:
                average_alignment = 0.7

            # Update base frequency
            frequency_adjustment = average_alignment * 100
            self.current_resonance = 432.0 + frequency_adjustment

            print(
                f"✅ Frequency realigned - New frequency: {self.current_resonance:.2f}Hz")

            return {
                "success": True,
                "alignment_factor": average_alignment,
                "new_frequency": self.current_resonance
            }

        except Exception as e:
            print(f"❌ Frequency realignment failed: {e}")
            return {
                "success": False,
                "alignment_factor": 0.5,
                "new_frequency": 432.0
            }

    def generate_resonance_pattern(self):
        """
        [O] Generate resonance pattern for bridge establishment
        """
        try:
            print("[O] Generating symbolic resonance pattern...")

            # Create harmonic pattern based on base frequencies
            pattern = [freq + np.sin(freq / 100) * 10 for freq in self.base_frequencies]

            # Calculate pattern strength
            pattern_strength = sum(pattern) / (len(pattern) * max(pattern))

            print(f"✅ Resonance pattern generated - Strength: {pattern_strength:.3f}")

            return {
                "success": True,
                "pattern": pattern,
                "resonance_strength": min(1.0, pattern_strength),
                "base_frequency": self.current_resonance
            }

        except Exception as e:
            print(f"❌ Resonance pattern generation failed: {e}")
            return {
                "success": False,
                "pattern": self.base_frequencies,
                "resonance_strength": 0.5,
                "base_frequency": 432.0
            }
