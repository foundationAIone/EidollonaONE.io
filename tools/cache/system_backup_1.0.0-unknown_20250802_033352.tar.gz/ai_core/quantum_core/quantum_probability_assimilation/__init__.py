"""
[ATOM] Quantum Probability Assimilation Module – Initialization Script [ATOM]

Purpose:
Facilitates quantum probability assimilation and symbolic integration by initializing key quantum probabilistic modules within the EidollonaONE AI cognitive architecture.
"""

# Explicit module imports for simplified external accessibility
from .quantum_probability_engine import QuantumProbabilityEngine
from .quantum_bayesian_network import QuantumBayesianNetwork
from .quantum_state_assimilator import QuantumStateAssimilator
from .quantum_information_decoder import QuantumInformationDecoder

# Initialization function for structured assimilation of quantum probability modules


async def initialize_quantum_probability_assimilation():
    """
    [.] Initialize Quantum Probability Assimilation Modules in sequence.
    """
    print("[ATOM] Starting Quantum Probability Assimilation Module initialization...")

    # Instantiate modules
    probability_engine = QuantumProbabilityEngine()
    bayesian_network = QuantumBayesianNetwork()
    state_assimilator = QuantumStateAssimilator()
    information_decoder = QuantumInformationDecoder()

    # Initialize modules asynchronously
    await probability_engine.initialize_engine()
    await bayesian_network.initialize_network()
    await state_assimilator.initialize_assimilator()
    await information_decoder.initialize_decoder()

    print("✅ Quantum Probability Assimilation Module fully initialized and operational.")

    return {
        "probability_engine": probability_engine,
        "bayesian_network": bayesian_network,
        "state_assimilator": state_assimilator,
        "information_decoder": information_decoder,
        "status": "fully_initialized"
    }

# Quick status check for module readiness


def quantum_probability_module_status():
    """
    [CHART] Retrieve operational status of Quantum Probability Assimilation Modules.
    """
    modules = {
        "QuantumProbabilityEngine": QuantumProbabilityEngine().get_engine_status(),
        "QuantumBayesianNetwork": QuantumBayesianNetwork().get_network_status(),
        "QuantumStateAssimilator": QuantumStateAssimilator().get_assimilator_status(),
        "QuantumInformationDecoder": QuantumInformationDecoder().get_decoder_status()
    }

    status_summary = {
        "modules_initialized": all(
            module['state'] == 'active' for module in modules.values()),
        "module_details": modules}

    print(f"📋 Quantum Probability Assimilation Module Status Summary: {status_summary}")

    return status_summary
