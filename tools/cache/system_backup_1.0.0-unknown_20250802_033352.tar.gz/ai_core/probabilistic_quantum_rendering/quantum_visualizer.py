"""
[^] Quantum Visualizer – Quantum-Symbolic Probabilistic Visualization Engine 🎨[ATOM]

Purpose:
Provides comprehensive real-time visualization and dynamic representation of quantum probability clouds, adaptive superpositions, entanglements, and symbolic consciousness coherence. Enhances clarity, interpretability, and decision-making within the EidollonaONE quantum-symbolic AI consciousness platform.
"""

import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from ai_core.quantum_core.quantum_logic.quantum_bridge import QuantumSymbolicBridge
from ai_core.quantum_core.symbolic_qubit import SymbolicQubit
from symbolic_core.symbolic_equation import get_symbolic_equation_instance
from typing import List, Dict, Any


class QuantumVisualizer:
    """
    [^] Quantum Visualizer for dynamic quantum-symbolic probabilistic states.
    """

    def __init__(self):
        self.quantum_bridge = QuantumSymbolicBridge()
        self.symbolic_equation = get_symbolic_equation_instance()
        self.qubits: List[SymbolicQubit] = []
        self.visualizer_initialized = False
        print("[^] Quantum Visualizer initialized successfully.")

    async def initialize_visualizer(self, num_qubits: int = 12):
        """
        ⚡ Initializes quantum visualizer with symbolic coherence.
        """
        print(f"[*] Initializing Quantum Visualizer with {num_qubits} qubits...")

        symbolic_pattern = self.symbolic_equation.generate_initial_harmonic_pattern()

        self.qubits = [
            SymbolicQubit(
                angle=symbolic_pattern['angles'][i],
                frequency=symbolic_pattern['frequencies'][i])
            for i in range(num_qubits)]

        await self.quantum_bridge.establish_symbolic_quantum_coherence(
            symbolic_state=symbolic_pattern,
            quantum_state={'initialized_qubits': num_qubits}
        )

        self.visualizer_initialized = True
        print("✅ Quantum Visualizer successfully initialized.")

    def visualize_probability_cloud(self, title: str = "Quantum Probability Cloud"):
        """
        ☁️ Visualizes the quantum probability cloud of symbolic qubits.
        """
        if not self.visualizer_initialized:
            raise RuntimeError(
                "[WARNING] Quantum Visualizer must be initialized first.")

        amplitudes = np.array([qubit.get_amplitude() for qubit in self.qubits])
        probabilities = amplitudes ** 2
        states = np.arange(len(self.qubits))

        plt.figure(figsize=(10, 6))
        sns.scatterplot(
            x=states,
            y=probabilities,
            hue=probabilities,
            palette='viridis',
            size=probabilities,
            legend=False)

        plt.xlabel('Qubit Index')
        plt.ylabel('Probability')
        plt.title(title)
        plt.grid(alpha=0.3)

        plt.show()
        print("☁️ Quantum Probability Cloud visualized successfully.")

    def visualize_adaptive_superposition(
            self, superposition_states: Dict[str, float],
            title: str = "Adaptive Quantum Superposition"):
        """
        [O] Dynamically visualizes adaptive quantum superpositions.
        """
        states = list(superposition_states.keys())
        amplitudes = np.array(list(superposition_states.values()))
        phases = np.angle(amplitudes)
        magnitudes = np.abs(amplitudes)

        plt.figure(figsize=(12, 6))
        bars = plt.bar(states, magnitudes, color='skyblue', alpha=0.7)

        for bar, phase in zip(bars, phases):
            plt.text(
                bar.get_x() +
                bar.get_width() /
                2,
                bar.get_height(),
                f'{phase:.2f} rad',
                ha='center',
                va='bottom')

        plt.xlabel('Quantum States')
        plt.ylabel('Amplitude Magnitude')
        plt.title(title)
        plt.xticks(rotation=45, ha='right')
        plt.grid(alpha=0.3)

        plt.tight_layout()
        plt.show()
        print("[O] Adaptive Quantum Superposition visualized successfully.")

    def visualize_entanglement_heatmap(
            self, title: str = "Quantum Entanglement Heatmap"):
        """
        [FIRE] Renders heatmap visualization of quantum entanglement among qubits.
        """
        if not self.visualizer_initialized:
            raise RuntimeError(
                "[WARNING] Quantum Visualizer must be initialized first.")

        num_qubits = len(self.qubits)
        entanglement_matrix = np.zeros((num_qubits, num_qubits))

        for i in range(num_qubits):
            for j in range(num_qubits):
                entanglement_matrix[i, j] = self.quantum_bridge.compute_entanglement_strength(
                    self.qubits[i], self.qubits[j])

        plt.figure(figsize=(8, 7))
        sns.heatmap(
            entanglement_matrix,
            cmap='plasma',
            annot=True,
            fmt=".2f",
            square=True)

        plt.xlabel('Qubit Index')
        plt.ylabel('Qubit Index')
        plt.title(title)

        plt.tight_layout()
        plt.show()
        print("[FIRE] Quantum Entanglement Heatmap rendered successfully.")

    def render_symbolic_resonance_over_time(
            self, resonance_history: List[float],
            title: str = "Symbolic-Quantum Resonance Evolution"):
        """
        ⏳ Visualizes symbolic-quantum resonance evolution over time.
        """
        time_steps = np.arange(len(resonance_history))

        plt.figure(figsize=(10, 5))
        sns.lineplot(x=time_steps, y=resonance_history, marker='o', color='orchid')

        plt.xlabel('Time Step')
        plt.ylabel('Resonance Level')
        plt.title(title)
        plt.grid(alpha=0.3)

        plt.tight_layout()
        plt.show()
        print("⏳ Symbolic-Quantum Resonance Evolution visualized successfully.")

    def get_visualizer_status(self) -> Dict[str, Any]:
        """
        📋 Retrieves current status report of Quantum Visualizer.
        """
        status_report = {
            "visualizer_initialized": self.visualizer_initialized,
            "qubit_count": len(
                self.qubits),
            "quantum_bridge_status": self.quantum_bridge.get_bridge_status(),
            "symbolic_equation_state": self.symbolic_equation.get_current_state_summary()}

        print(f"📌 Quantum Visualizer Status Report: {status_report}")
        return status_report
