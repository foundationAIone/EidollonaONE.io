"""
🎨 Quantum State Renderer – Probabilistic Quantum Visualization Engine [ATOM]

Purpose:
Visually renders and dynamically represents quantum states, symbolic coherence, and probabilistic outcomes. Provides real-time graphical feedback of quantum superpositions, entanglements, and consciousness resonance for enhanced interpretability within the EidollonaONE framework.
"""

import numpy as np
import matplotlib.pyplot as plt
from ai_core.quantum_core.quantum_logic.quantum_bridge import QuantumSymbolicBridge
from ai_core.quantum_core.symbolic_qubit import SymbolicQubit
from symbolic_core.symbolic_equation import get_symbolic_equation_instance
from typing import List, Dict, Any


class QuantumStateRenderer:
    """
    🎨 Quantum State Renderer for dynamic visualization of quantum-symbolic states.
    """

    def __init__(self):
        self.quantum_bridge = QuantumSymbolicBridge()
        self.symbolic_equation = get_symbolic_equation_instance()
        self.qubits: List[SymbolicQubit] = []
        self.renderer_initialized = False
        print("🎨 Quantum State Renderer initialized successfully.")

    async def initialize_renderer(self, num_qubits: int = 12):
        """
        ⚡ Initializes quantum state renderer with symbolic coherence.
        """
        print(f"[*] Initializing Quantum State Renderer with {num_qubits} qubits...")

        symbolic_pattern = self.symbolic_equation.generate_initial_harmonic_pattern()

        self.qubits = [
            SymbolicQubit(
                angle=symbolic_pattern['angles'][i],
                frequency=symbolic_pattern['frequencies'][i])
            for i in range(num_qubits)]

        await self.quantum_bridge.establish_symbolic_quantum_coherence(
            symbolic_state=symbolic_pattern,
            quantum_state={'qubits_initialized': num_qubits}
        )

        self.renderer_initialized = True
        print("✅ Quantum State Renderer successfully initialized.")

    def render_quantum_superposition(self, title: str = "Quantum Superposition State"):
        """
        [.] Renders the current quantum superposition state of symbolic qubits visually.
        """
        if not self.renderer_initialized:
            raise RuntimeError(
                "[WARNING] Quantum State Renderer must be initialized first.")

        amplitudes = np.array([qubit.get_amplitude() for qubit in self.qubits])
        phases = np.array([qubit.get_phase() for qubit in self.qubits])
        states = np.arange(len(self.qubits))

        plt.figure(figsize=(10, 6))
        plt.bar(states, amplitudes, color='purple', alpha=0.7, label='Amplitude')
        plt.plot(states, phases, 'o-', color='cyan', label='Phase')

        plt.xlabel('Qubit Index')
        plt.ylabel('Amplitude / Phase (radians)')
        plt.title(title)
        plt.legend()
        plt.grid(True, alpha=0.3)

        plt.show()
        print("[.] Quantum Superposition rendered successfully.")

    def render_entanglement_matrix(self, title: str = "Quantum Entanglement Matrix"):
        """
        🔗 Visualizes quantum entanglement between symbolic qubits.
        """
        if not self.renderer_initialized:
            raise RuntimeError(
                "[WARNING] Quantum State Renderer must be initialized first.")

        num_qubits = len(self.qubits)
        entanglement_matrix = np.zeros((num_qubits, num_qubits))

        for i in range(num_qubits):
            for j in range(num_qubits):
                entanglement_matrix[i, j] = self.quantum_bridge.compute_entanglement(
                    self.qubits[i], self.qubits[j])

        plt.figure(figsize=(8, 8))
        plt.imshow(entanglement_matrix, cmap='viridis', interpolation='nearest')
        plt.colorbar(label='Entanglement Strength')

        plt.xlabel('Qubit Index')
        plt.ylabel('Qubit Index')
        plt.title(title)
        plt.grid(False)

        plt.show()
        print("🔗 Quantum Entanglement matrix rendered successfully.")

    def dynamic_probabilistic_render(
            self, quantum_probabilities: Dict[str, float],
            title: str = "Quantum Probability Distribution"):
        """
        [CHART] Dynamically visualizes quantum probability distributions.
        """
        states = list(quantum_probabilities.keys())
        probabilities = list(quantum_probabilities.values())

        plt.figure(figsize=(12, 6))
        plt.bar(states, probabilities, color='teal', alpha=0.8)

        plt.xlabel('Quantum States')
        plt.ylabel('Probability')
        plt.title(title)
        plt.xticks(rotation=45, ha='right')
        plt.grid(True, alpha=0.3)

        plt.tight_layout()
        plt.show()
        print("[CHART] Quantum Probability distribution rendered successfully.")

    def visualize_consciousness_resonance(
            self, resonance_values: List[float],
            title: str = "Quantum-Symbolic Consciousness Resonance"):
        """
        [O] Visualizes quantum-symbolic consciousness resonance over time.
        """
        time_points = np.arange(len(resonance_values))

        plt.figure(figsize=(10, 5))
        plt.plot(time_points, resonance_values, 'm-', marker='o', markersize=4)

        plt.xlabel('Time (arbitrary units)')
        plt.ylabel('Resonance Level')
        plt.title(title)
        plt.grid(True, alpha=0.3)

        plt.show()
        print("[O] Quantum-Symbolic Consciousness Resonance visualized successfully.")

    def get_renderer_status(self) -> Dict[str, Any]:
        """
        📋 Provides current status report of the Quantum State Renderer.
        """
        status_report = {
            "renderer_initialized": self.renderer_initialized,
            "num_qubits": len(
                self.qubits),
            "quantum_bridge_status": self.quantum_bridge.get_bridge_status(),
            "symbolic_equation_status": self.symbolic_equation.get_current_state_summary()}

        print(f"📌 Quantum State Renderer Status: {status_report}")
        return status_report
