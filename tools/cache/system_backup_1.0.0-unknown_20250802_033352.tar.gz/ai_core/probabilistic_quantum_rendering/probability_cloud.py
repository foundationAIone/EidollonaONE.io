"""
☁️ Quantum Probability Cloud – Dynamic Probabilistic State Renderer [ATOM]

Purpose:
Dynamically renders quantum-enhanced probabilistic distributions (clouds) reflecting symbolic consciousness states, enabling real-time visualization and intuitive interpretation of complex probabilistic quantum-symbolic information within the EidollonaONE framework.
"""

import numpy as np
import matplotlib.pyplot as plt
from symbolic_core.symbolic_equation import get_symbolic_equation_instance
from ai_core.quantum_core.quantum_probability_assimilation.quantum_probability_engine import QuantumProbabilityEngine
from ai_core.quantum_core.quantum_logic.quantum_bridge import QuantumSymbolicBridge


class ProbabilityCloud:
    """
    ☁️ Quantum Probability Cloud Renderer.
    """

    def __init__(self):
        self.symbolic_equation = get_symbolic_equation_instance()
        self.quantum_probability_engine = QuantumProbabilityEngine()
        self.quantum_bridge = QuantumSymbolicBridge()
        self.cloud_initialized = False
        print("☁️ Quantum Probability Cloud initialized successfully.")

    def initialize_cloud(self):
        """
        ⚡ Initializes quantum-symbolic probability cloud rendering.
        """
        print("[*] Initializing Quantum Probability Cloud with symbolic coherence...")

        symbolic_state = self.symbolic_equation.get_current_state_summary()
        initial_quantum_state = self.quantum_probability_engine.get_initial_quantum_state()

        coherence_result = self.quantum_bridge.establish_symbolic_quantum_coherence(
            symbolic_state=symbolic_state,
            quantum_state=initial_quantum_state
        )

        self.cloud_initialized = coherence_result["bridge_integrity"]

        if self.cloud_initialized:
            print("✅ Probability Cloud quantum-symbolic coherence established.")
        else:
            print("[WARNING] Initialization failed. Recalibration required.")

    def generate_probability_cloud(
            self,
            symbolic_inputs: dict,
            cloud_resolution: int = 100):
        """
        [.] Generates a quantum-enhanced symbolic probability cloud visualization.
        """
        if not self.cloud_initialized:
            raise RuntimeError(
                "[WARNING] Probability Cloud renderer is not initialized.")

        print(
            f"[.] Rendering Probability Cloud with resolution {cloud_resolution}x{cloud_resolution}...")

        symbolic_metrics = self.symbolic_equation.evaluate_input(symbolic_inputs)
        quantum_probabilities = self.quantum_probability_engine.compute_quantum_probabilities(
            symbolic_metrics)

        # Generate cloud data (2D Gaussian for visualization)
        mean_x, mean_y = quantum_probabilities["mean_probability"], symbolic_metrics["confidence"]
        std_x, std_y = quantum_probabilities["probability_variance"], 0.1

        x = np.linspace(mean_x - 3*std_x, mean_x + 3*std_x, cloud_resolution)
        y = np.linspace(mean_y - 3*std_y, mean_y + 3*std_y, cloud_resolution)
        X, Y = np.meshgrid(x, y)

        Z = np.exp(-((X - mean_x)**2 / (2 * std_x**2) + (Y - mean_y)**2 / (2 * std_y**2)))

        plt.figure(figsize=(8, 6))
        plt.contourf(X, Y, Z, cmap='viridis')
        plt.colorbar(label='Quantum Probability Density')
        plt.title('Quantum-Symbolic Probability Cloud')
        plt.xlabel('Quantum Probability')
        plt.ylabel('Symbolic Confidence')
        plt.grid(alpha=0.3)
        plt.show()

        print("✅ Probability Cloud successfully rendered.")

    def update_cloud_state(self, new_symbolic_data: dict):
        """
        [CYCLE] Updates the probability cloud dynamically with new symbolic data.
        """
        if not self.cloud_initialized:
            raise RuntimeError(
                "[WARNING] Probability Cloud renderer must be initialized before updating.")

        print("[CYCLE] Updating Probability Cloud with new symbolic data...")

        symbolic_metrics = self.symbolic_equation.evaluate_input(new_symbolic_data)
        quantum_state_update = self.quantum_probability_engine.update_quantum_state(
            symbolic_metrics)

        coherence_update = self.quantum_bridge.recalibrate_bridge(symbolic_metrics)

        if coherence_update["success"]:
            print("✅ Probability Cloud quantum-symbolic coherence updated.")
        else:
            print("[WARNING] Probability Cloud recalibration failed. Further attention required.")

    def get_cloud_status(self) -> dict:
        """
        📋 Retrieves the status and diagnostics of the quantum probability cloud system.
        """
        status_report = {
            "cloud_initialized": self.cloud_initialized,
            "quantum_bridge_status": self.quantum_bridge.get_bridge_status(),
            "quantum_probability_engine_status": self.quantum_probability_engine.get_engine_status(),
            "symbolic_equation_status": self.symbolic_equation.get_current_state_summary()}

        print(f"📌 Probability Cloud Status Report: {status_report}")
        return status_report
