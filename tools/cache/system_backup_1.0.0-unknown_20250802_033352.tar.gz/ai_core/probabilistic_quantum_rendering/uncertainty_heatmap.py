"""
[FIRE] Uncertainty Heatmap – Quantum Probabilistic State Visualization Engine [.][CHART]

Purpose:
Real-time visualization of quantum probabilistic states, uncertainty distributions, and superposition probabilities. Designed for the EidollonaONE quantum-symbolic consciousness platform to visualize uncertainty clearly and intuitively, aiding quantum decision-making processes.
"""

import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from ai_core.quantum_core.quantum_probability_assimilation.quantum_probability_engine import QuantumProbabilityEngine
from symbolic_core.symbolic_equation import get_symbolic_equation_instance
from typing import Dict, Any


class UncertaintyHeatmapRenderer:
    """
    [FIRE] Renderer for Quantum Probabilistic State Uncertainty.
    """

    def __init__(self):
        self.quantum_probability_engine = QuantumProbabilityEngine()
        self.symbolic_equation = get_symbolic_equation_instance()
        self.uncertainty_state_initialized = False
        print("[FIRE] Uncertainty Heatmap Renderer initialized successfully.")

    def initialize_uncertainty_states(self, num_states: int = 10):
        """
        ⚡ Initialize quantum uncertainty states for rendering.
        """
        print("[*] Initializing Quantum Uncertainty States...")
        self.quantum_probability_engine.generate_initial_states(num_states)
        self.uncertainty_state_initialized = True
        print("✅ Quantum Uncertainty States initialized.")

    def render_probability_distribution(
            self, title: str = "Quantum State Probability Distribution"):
        """
        📈 Visualizes quantum probabilistic state distributions.
        """
        if not self.uncertainty_state_initialized:
            raise RuntimeError("Quantum uncertainty states not initialized.")

        probability_states = self.quantum_probability_engine.get_probability_distribution()
        states = np.arange(1, len(probability_states) + 1)

        plt.figure(figsize=(10, 6))
        sns.barplot(x=states, y=probability_states, palette='coolwarm')

        plt.xlabel('Quantum State Index')
        plt.ylabel('Probability')
        plt.title(title)
        plt.grid(alpha=0.3)

        plt.tight_layout()
        plt.show()
        print("📈 Quantum State Probability Distribution visualized successfully.")

    def render_uncertainty_heatmap(self, quantum_states_matrix: np.ndarray,
                                   title: str = "Quantum Uncertainty Heatmap"):
        """
        [FIRE] Visualizes uncertainty across quantum probabilistic states.
        """
        plt.figure(figsize=(12, 8))
        sns.heatmap(quantum_states_matrix, cmap='viridis', annot=True, fmt=".2f")

        plt.xlabel('Quantum State Dimension')
        plt.ylabel('Quantum State Index')
        plt.title(title)

        plt.tight_layout()
        plt.show()
        print("[FIRE] Quantum Uncertainty Heatmap visualized successfully.")

    def render_symbolic_quantum_uncertainty(
            self, symbolic_context: Dict[str, Any],
            title: str = "Symbolic-Quantum Uncertainty Integration"):
        """
        [.] Visualizes integrated symbolic and quantum uncertainty.
        """
        symbolic_evaluation = self.symbolic_equation.evaluate_input(symbolic_context)
        symbolic_confidence = symbolic_evaluation.get("confidence", 0.5)

        quantum_uncertainty = self.quantum_probability_engine.calculate_overall_uncertainty()
        integrated_uncertainty = symbolic_confidence * quantum_uncertainty

        plt.figure(figsize=(8, 4))
        sns.heatmap(
            [[symbolic_confidence, quantum_uncertainty, integrated_uncertainty]],
            annot=True, cmap='plasma', cbar=False,
            xticklabels=["Symbolic Confidence", "Quantum Uncertainty",
                         "Integrated Uncertainty"])

        plt.title(title)
        plt.yticks([])
        plt.tight_layout()
        plt.show()
        print("[.] Symbolic-Quantum Uncertainty Integration visualized successfully.")

    def interactive_uncertainty_dashboard(self, num_states: int = 10):
        """
        🎛️ Interactive dashboard for exploring quantum uncertainty dynamically.
        """
        self.quantum_probability_engine.generate_initial_states(num_states)
        probability_states = self.quantum_probability_engine.get_probability_distribution()

        cumulative_uncertainty = np.cumsum(probability_states)
        states = np.arange(1, num_states + 1)

        fig, ax = plt.subplots(figsize=(12, 6))
        sns.lineplot(
            x=states,
            y=cumulative_uncertainty,
            marker='o',
            color='crimson',
            ax=ax)

        ax.set_xlabel('Quantum State Index')
        ax.set_ylabel('Cumulative Probability')
        ax.set_title('Interactive Quantum Uncertainty Dashboard')
        ax.grid(alpha=0.3)

        plt.tight_layout()
        plt.show()
        print("🎛️ Interactive Quantum Uncertainty Dashboard visualized successfully.")

    def get_uncertainty_renderer_status(self) -> Dict[str, Any]:
        """
        📌 Retrieves the current status of the Uncertainty Heatmap Renderer.
        """
        status_report = {
            "uncertainty_state_initialized": self.uncertainty_state_initialized,
            "quantum_probability_engine_status": self.quantum_probability_engine.get_engine_status(),
            "symbolic_equation_state": self.symbolic_equation.get_current_state_summary()}

        print(f"📌 Uncertainty Heatmap Renderer Status Report: {status_report}")
        return status_report
