# Interaction Controllers

This module provides:
- LookAtMouse: head/eye look target from mouse pointer via raycasting.
- PatrolController: ping-pong between waypoints (walk → turn → walk back).
- ClickToMoveController: click/command a world target and walk there.

## Quick Wire (React Three Fiber)

```jsx
import * as THREE from 'three'
import { AnimationOrchestrator } from '../components/animation_controller.js'
import { PoseLayers } from '../components/pose_layers.js'
import { FootIK } from '../components/ik_solver.js'
import { LookAtMouse, PatrolController, ClickToMoveController } from '../components/movement_interaction.js'

// After GLB loads
const ground = groundRef.current ? [groundRef.current] : []
const ac = new AnimationOrchestrator({ root: gltf.scene, clips: gltf.animations, groundMeshes: ground })
const pose = new PoseLayers({ root: gltf.scene })
const ik = FootIK.fromHumanoid(gltf.scene, gltf.scene.parent, ground)
ac.bindPoseLayer(pose)
ac.bindIK(ik)

// Head look
const look = new LookAtMouse({ camera, scene: gltf.scene.parent, pose, rayMeshes: ground, planeY: 0 })
look.attach(gl.domElement)

// Patrol A ↔ B
const p0 = gltf.scene.position.clone().add(new THREE.Vector3(0, 0, -2))
const p1 = gltf.scene.position.clone().add(new THREE.Vector3(0, 0,  2))
const patrol = new PatrolController({ root: gltf.scene, controller: ac, points: [p0, p1], speed: 1.3 })

// Click to move
const ctm = new ClickToMoveController({ root: gltf.scene, controller: ac })

gl.domElement.addEventListener('click', (ev) => {
  const { left, top, width, height } = gl.domElement.getBoundingClientRect()
  const ndc = new THREE.Vector2(((ev.clientX - left)/width)*2 - 1, -((ev.clientY - top)/height)*2 + 1)
  const rc = new THREE.Raycaster()
  rc.setFromCamera(ndc, camera)
  const hits = rc.intersectObjects(ground, true)
  if (hits.length) ctm.setTarget(hits[0].point)
})

useFrame((_, dt) => {
  ctm.update(dt)
  patrol.update(dt)
  ac.update(dt)
})
```

## Vanilla Script Tag (static viewer)

```html
<script type="module">
  import { LookAtMouse, PatrolController, ClickToMoveController } from './frontend/components/movement_interaction.js'
  // assume you have: ac, pose, avatar, camera, renderer, ground

  const look = new LookAtMouse({ camera, scene, pose, rayMeshes: [ground], planeY: 0 })
  look.attach(renderer.domElement)

  const p0 = avatar.position.clone().add(new THREE.Vector3(0,0,-2))
  const p1 = avatar.position.clone().add(new THREE.Vector3(0,0, 2))
  const patrol = new PatrolController({ root: avatar, controller: ac, points: [p0, p1], speed: 1.3 })

  const ctm = new ClickToMoveController({ root: avatar, controller: ac })

  renderer.domElement.addEventListener('click', (ev) => {
    const rect = renderer.domElement.getBoundingClientRect()
    const ndc = new THREE.Vector2(((ev.clientX-rect.left)/rect.width)*2-1, -((ev.clientY-rect.top)/rect.height)*2+1)
    const rc = new THREE.Raycaster()
    rc.setFromCamera(ndc, camera)
    const hits = rc.intersectObjects([ground], true)
    if (hits.length) ctm.setTarget(hits[0].point)
  })

  let last = performance.now()
  function animate(now){
    const dt = (now - last)/1000; last = now
    ctm.update(dt); patrol.update(dt); ac.update(dt)
    requestAnimationFrame(animate)
  }
  requestAnimationFrame(animate)
</script>
```

Notes:
- Pass ground meshes for raycasting and optional foot IK.
- Controllers are allocation-light; keep them updated once per frame.
- Clip heuristics live in animation_controller.js; adjust to match your asset names.
