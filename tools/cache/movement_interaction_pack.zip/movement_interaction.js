import * as THREE from 'three'
/**
 * movement_interaction.js
 * Interaction controllers for live movement in Three.js / R3F scenes.
 * - LookAtMouse: head/eye look target driven by mouse pointer via raycaster
 * - PatrolController: ping-pong between waypoints (walk -> turn -> walk back)
 * - ClickToMoveController: set a target point at runtime; walk and face target
 *
 * Controllers expect an AnimationOrchestrator-like controller with:
 *   setSpeedMetersPerSecond(speedMps) or setSpeed(speedMps), and playLocomotion/setState(state)
 */

export class LookAtMouse {
  constructor({ camera, scene, pose, rayMeshes = [], planeY = 0 }) {
    this.camera = camera
    this.scene = scene
    this.pose = pose
    this.rayMeshes = rayMeshes
    this.planeY = planeY
    this.enabled = true

    this._raycaster = new THREE.Raycaster()
    this._ndc = new THREE.Vector2()
    this._plane = new THREE.Plane(new THREE.Vector3(0, 1, 0), -planeY)

    this._onPointerMove = this._onPointerMove.bind(this)
  }

  attach(domElement) {
    if (!domElement) return
    domElement.addEventListener('pointermove', this._onPointerMove, { passive: true })
  }

  detach(domElement) {
    if (!domElement) return
    domElement.removeEventListener('pointermove', this._onPointerMove)
  }

  _onPointerMove(ev) {
    if (!this.enabled || !this.camera) return
    const rect = ev.currentTarget.getBoundingClientRect()
    this._ndc.x = ((ev.clientX - rect.left) / rect.width) * 2 - 1
    this._ndc.y = -((ev.clientY - rect.top) / rect.height) * 2 + 1

    this._raycaster.setFromCamera(this._ndc, this.camera)

    // Prefer ray against meshes; fallback to ground plane
    if (this.rayMeshes && this.rayMeshes.length) {
      const hits = this._raycaster.intersectObjects(this.rayMeshes, true)
      if (hits.length) {
        this.pose?.setHeadLookTarget?.(hits[0].point)
        return
      }
    }

    const hit = new THREE.Vector3()
    if (this._raycaster.ray.intersectPlane(this._plane, hit)) {
      this.pose?.setHeadLookTarget?.(hit)
    }
  }
}

export class PatrolController {
  constructor({ root, controller, points = [], speed = 1.3, turnSpeed = 8.0, arriveRadius = 0.1 }) {
    this.root = root
    this.controller = controller
    this.points = points
    this.speed = speed // meters per second
    this.turnSpeed = turnSpeed // slerp factor per second
    this.arriveRadius = arriveRadius // meters
    this.index = 0
    this.forward = true
    this.enabled = true

    this._dir = new THREE.Vector3()
    this._targetQuat = new THREE.Quaternion()
  }

  _setSpeed(v) {
    if (!this.controller) return
    if (typeof this.controller.setSpeedMetersPerSecond === 'function') this.controller.setSpeedMetersPerSecond(v)
    else if (typeof this.controller.setSpeed === 'function') this.controller.setSpeed(v)
  }

  update(dt) {
    if (!this.enabled || !this.root || this.points.length < 2) return

    const target = this.points[this.index]
    const pos = this.root.position
    const dir = this._dir.subVectors(target, pos)
    const dist = dir.length()

    if (dist < this.arriveRadius) {
      if (this.forward && this.index === this.points.length - 1) this.forward = false
      else if (!this.forward && this.index === 0) this.forward = true
      this.index += this.forward ? 1 : -1
      return
    }

    dir.normalize()
    pos.addScaledVector(dir, this.speed * dt)

    // Face movement direction (yaw only)
    const yaw = Math.atan2(dir.x, dir.z)
    this._targetQuat.setFromAxisAngle(new THREE.Vector3(0, 1, 0), yaw)
    this.root.quaternion.slerp(this._targetQuat, THREE.MathUtils.clamp(this.turnSpeed * dt, 0, 1))

    this._setSpeed(this.speed)
  }
}

export class ClickToMoveController {
  constructor({ root, controller, arriveRadius = 0.15, maxSpeed = 1.6, turnSpeed = 10.0 }) {
    this.root = root
    this.controller = controller
    this.arriveRadius = arriveRadius
    this.maxSpeed = maxSpeed
    this.turnSpeed = turnSpeed
    this.enabled = true
    this.target = null

    this._dir = new THREE.Vector3()
    this._targetQuat = new THREE.Quaternion()
  }

  _setSpeed(v) {
    if (!this.controller) return
    if (typeof this.controller.setSpeedMetersPerSecond === 'function') this.controller.setSpeedMetersPerSecond(v)
    else if (typeof this.controller.setSpeed === 'function') this.controller.setSpeed(v)
  }

  setTarget(vec3) { this.target = vec3 ? vec3.clone() : null }
  clearTarget() { this.target = null }

  update(dt) {
    if (!this.enabled || !this.root) return
    if (!this.target) { this._setSpeed(0); return }

    const pos = this.root.position
    const dir = this._dir.subVectors(this.target, pos)
    const dist = dir.length()

    if (dist < this.arriveRadius) {
      this._setSpeed(0)
      this.target = null
      return
    }

    dir.normalize()
    const speed = Math.min(this.maxSpeed, dist / Math.max(dt, 1e-3))
    pos.addScaledVector(dir, speed * dt)

    const yaw = Math.atan2(dir.x, dir.z)
    this._targetQuat.setFromAxisAngle(new THREE.Vector3(0, 1, 0), yaw)
    this.root.quaternion.slerp(this._targetQuat, THREE.MathUtils.clamp(this.turnSpeed * dt, 0, 1))

    this._setSpeed(speed)
  }
}
