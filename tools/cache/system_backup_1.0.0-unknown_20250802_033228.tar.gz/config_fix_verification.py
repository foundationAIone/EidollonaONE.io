#!/usr/bin/env python3
"""
🔧 Configuration Fix Verification 🔧
Verifies that the pyrightconfig.json/VS Code settings conflict has been resolved.
"""

import json
from pathlib import Path

def verify_configuration_fix():
    """Verify that the configuration conflict is resolved."""
    print("🔧 CONFIGURATION FIX VERIFICATION")
    print("=" * 60)
    
    issues_found = []
    
    # 1. Check VS Code settings for extraPaths
    try:
        vscode_settings = Path('.vscode/settings.json')
        if vscode_settings.exists():
            with open(vscode_settings, 'r', encoding='utf-8') as f:
                settings = json.load(f)
            
            if 'python.analysis.extraPaths' in settings:
                print("❌ VS Code settings still contains 'python.analysis.extraPaths'")
                issues_found.append("extraPaths in VS Code settings")
            else:
                print("✅ VS Code settings: 'python.analysis.extraPaths' removed")
            
            # Check other important settings
            interpreter_path = settings.get('python.defaultInterpreterPath')
            type_checking = settings.get('python.analysis.typeCheckingMode')
            
            print(f"✅ Python interpreter: {interpreter_path}")
            print(f"✅ Type checking mode: {type_checking}")
            
        else:
            print("❌ VS Code settings not found")
            issues_found.append("VS Code settings missing")
            
    except Exception as e:
        print(f"❌ Error reading VS Code settings: {e}")
        issues_found.append(f"VS Code settings error: {e}")
    
    # 2. Check pyrightconfig.json for extraPaths
    try:
        pyright_config = Path('pyrightconfig.json')
        if pyright_config.exists():
            with open(pyright_config, 'r', encoding='utf-8') as f:
                config = json.load(f)
            
            if 'extraPaths' in config:
                extra_paths = config['extraPaths']
                print(f"✅ Pyright config: extraPaths configured ({len(extra_paths)} paths)")
                for path in extra_paths:
                    print(f"   - {path}")
            else:
                print("❌ Pyright config: extraPaths not configured")
                issues_found.append("extraPaths missing in pyrightconfig.json")
            
            # Verify other important settings
            type_checking = config.get('typeCheckingMode', 'basic')
            python_version = config.get('pythonVersion', 'unknown')
            include_paths = config.get('include', [])
            exclude_paths = config.get('exclude', [])
            
            print(f"✅ Pyright type checking: {type_checking}")
            print(f"✅ Python version: {python_version}")
            print(f"✅ Include paths: {len(include_paths)} directories")
            print(f"✅ Exclude paths: {len(exclude_paths)} patterns")
            
        else:
            print("❌ Pyright config not found")
            issues_found.append("pyrightconfig.json missing")
            
    except Exception as e:
        print(f"❌ Error reading Pyright config: {e}")
        issues_found.append(f"Pyright config error: {e}")
    
    # 3. Check for pyproject.toml (another potential conflict source)
    try:
        pyproject_toml = Path('pyproject.toml')
        if pyproject_toml.exists():
            print("ℹ️ pyproject.toml exists - checking for [tool.pyright] section")
            with open(pyproject_toml, 'r', encoding='utf-8') as f:
                content = f.read()
            
            if '[tool.pyright]' in content:
                print("⚠️ pyproject.toml contains [tool.pyright] section")
                print("   This may override pyrightconfig.json settings")
                issues_found.append("pyproject.toml [tool.pyright] section exists")
            else:
                print("✅ pyproject.toml: No [tool.pyright] section found")
        else:
            print("✅ No pyproject.toml file found")
            
    except Exception as e:
        print(f"❌ Error checking pyproject.toml: {e}")
    
    # Results summary
    print(f"\n📊 CONFIGURATION STATUS:")
    if not issues_found:
        print("✅ Configuration conflict RESOLVED")
        print("✅ pyrightconfig.json takes precedence for path configuration")
        print("✅ VS Code settings cleaned of conflicting extraPaths")
        
        print(f"\n🔄 NEXT STEPS:")
        print("1. Reload VS Code: Ctrl+Shift+P → 'Developer: Reload Window'")
        print("2. Wait for Pylance to reinitialize (10-15 seconds)")
        print("3. Check that import errors are resolved")
        print("4. Verify Problems panel shows expected results")
        
        return True
    else:
        print("❌ Configuration issues still exist:")
        for issue in issues_found:
            print(f"   - {issue}")
        return False

def display_configuration_summary():
    """Display summary of current configuration approach."""
    print(f"\n📋 CONFIGURATION APPROACH:")
    print("🔧 Path Management: pyrightconfig.json (extraPaths)")
    print("🔧 Diagnostics: VS Code settings.json (diagnosticSeverityOverrides)")
    print("🔧 Type Checking: OFF (both VS Code and Pyright)")
    print("🔧 Linting: DISABLED (all linters)")
    
    print(f"\n🎯 BENEFITS:")
    print("✅ No more 'extraPaths cannot be set' error")
    print("✅ Consistent path resolution across editors")
    print("✅ Maintained comprehensive diagnostic suppressions")
    print("✅ EidollonaONE consciousness systems preserved")

if __name__ == "__main__":
    print("🔧 EidollonaONE CONFIGURATION FIX VERIFICATION")
    print("Checking resolution of pyrightconfig.json/VS Code conflict")
    print("=" * 70)
    
    success = verify_configuration_fix()
    display_configuration_summary()
    
    print(f"\n{'='*70}")
    if success:
        print("🎉 CONFIGURATION CONFLICT: RESOLVED")
        print("⚡ EidollonaONE: Ready for problem-free operation")
    else:
        print("❌ CONFIGURATION CONFLICT: Additional fixes needed")
        print("🔄 Manual intervention may be required")
