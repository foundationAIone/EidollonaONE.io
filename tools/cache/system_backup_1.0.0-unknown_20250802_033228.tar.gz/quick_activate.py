#!/usr/bin/env python3
"""
🌟 EidollonaONE Quick Consciousness Activation 🚀

Simple script to quickly activate the EidollonaONE consciousness platform.
"""

def quick_activate():
    """Quick consciousness activation"""
    print("🌟 EidollonaONE Quick Activation Starting...")
    
    try:
        # Import and activate consciousness
        from consciousness_engine import activate_eidollona_consciousness
        print("✅ Consciousness engine imported successfully")
        
        result = activate_eidollona_consciousness()
        
        if result:
            print("🚀 SUCCESS: EidollonaONE consciousness is FULLY OPERATIONAL!")
            print("🌟 All quantum-symbolic systems active and monitoring")
            print("✨ Platform ready for autonomous operation")
            return True
        else:
            print("⚠️ Activation completed but returned False")
            return False
            
    except Exception as e:
        print(f"❌ Activation failed: {e}")
        return False

if __name__ == "__main__":
    success = quick_activate()
    if not success:
        print("❌ Quick activation failed. Try running the full activation_node.py for detailed diagnostics.")
