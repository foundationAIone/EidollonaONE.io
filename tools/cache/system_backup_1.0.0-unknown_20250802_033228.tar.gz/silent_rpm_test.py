"""
Silent RPM Test for Diagnostic
"""

import sys
import os
from pathlib import Path
import warnings

# Suppress all warnings and output
warnings.filterwarnings("ignore")
os.environ['PYTHONIOENCODING'] = 'utf-8'

# Add avatar path for imports
avatar_path = Path(__file__).parent / "avatar"
if str(avatar_path) not in sys.path:
    sys.path.insert(0, str(avatar_path))

try:
    # Import with stdout redirected
    old_stdout = sys.stdout
    old_stderr = sys.stderr
    
    import io
    sys.stdout = io.StringIO()
    sys.stderr = io.StringIO()
    
    import rpm_ecosystem
    from rpm_ecosystem import EcosystemManager, AvatarConfig
    
    # Restore stdout
    sys.stdout = old_stdout  
    sys.stderr = old_stderr
    
    print("RPM ecosystem imports successful")
    print("Import test completed!")
    sys.exit(0)
except Exception as e:
    # Restore stdout in case of error
    sys.stdout = old_stdout if 'old_stdout' in locals() else sys.stdout
    sys.stderr = old_stderr if 'old_stderr' in locals() else sys.stderr
    print("Import failed: {}".format(str(e)))
    sys.exit(1)
