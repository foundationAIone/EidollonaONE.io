"""
[ATOM] Shor's Quantum Factorization Module [ATOM]

Purpose:
Leverage quantum computing (via Qiskit) to efficiently factor integers using Shor's algorithm.
Integral part of EidollonaONE's quantum processing for secure cryptographic operations, quantum risk management, and symbolic quantum coherence validation.
"""

import logging
import math
from typing import Dict, Any, Optional, List
from datetime import datetime

# Modern Qiskit imports with comprehensive fallback handling
QISKIT_AVAILABLE = False
SHOR_AVAILABLE = False
SHOR_SOURCE = None

try:
    # Core Qiskit components (modern API)
    from qiskit import QuantumCircuit, transpile
    from qiskit_aer import AerSimulator
    QISKIT_AVAILABLE = True
    logging.info("✅ Core Qiskit components loaded")

    # Try modern qiskit-algorithms package first
    try:
        from qiskit_algorithms import Shor
        SHOR_AVAILABLE = True
        SHOR_SOURCE = "qiskit_algorithms"
        logging.info("✅ Using modern qiskit-algorithms package")

        # Try to get primitives for modern approach
        try:
            from qiskit.primitives import Sampler
            PRIMITIVES_AVAILABLE = True
        except ImportError:
            try:
                from qiskit_aer.primitives import Sampler
                PRIMITIVES_AVAILABLE = True
            except ImportError:
                PRIMITIVES_AVAILABLE = False

    except ImportError:
        # Fallback to legacy qiskit.algorithms (suppress import errors)
        try:
            import sys
            from io import StringIO

            # Temporarily suppress stderr to avoid import warnings
            old_stderr = sys.stderr
            sys.stderr = StringIO()

            from qiskit.algorithms import Shor  # type: ignore
            from qiskit.utils import QuantumInstance  # type: ignore
            from qiskit import Aer  # type: ignore

            # Restore stderr
            sys.stderr = old_stderr

            SHOR_AVAILABLE = True
            SHOR_SOURCE = "qiskit_legacy"
            PRIMITIVES_AVAILABLE = False
            logging.info("✅ Using legacy qiskit.algorithms")

        except ImportError:
            # Restore stderr and continue without Shor
            sys.stderr = old_stderr
            SHOR_AVAILABLE = False
            SHOR_SOURCE = "none"
            PRIMITIVES_AVAILABLE = False
            logging.info(
                "ℹ️  Shor algorithm not available - using classical fallback methods")

except ImportError as e:
    logging.warning(f"❌ Qiskit not available: {e}")
    QISKIT_AVAILABLE = False
    SHOR_AVAILABLE = False
    SHOR_SOURCE = "none"
    PRIMITIVES_AVAILABLE = False


class ShorFactorization:
    def __init__(self, backend: Optional[str] = "aer_simulator", shots: int = 1024):
        self.shots = shots
        self.factorization_history = []
        self.quantum_coherence = 1.0

        if QISKIT_AVAILABLE:
            try:
                # Use modern Qiskit backend initialization
                self.backend = AerSimulator()
                self.qiskit_ready = True

                # Initialize Shor algorithm if available
                if SHOR_AVAILABLE:
                    if SHOR_SOURCE == "qiskit_algorithms":
                        # Modern approach
                        if PRIMITIVES_AVAILABLE:
                            sampler = Sampler()
                            self.shor_algorithm = Shor(sampler=sampler)
                        else:
                            self.shor_algorithm = Shor()
                    elif SHOR_SOURCE == "qiskit_legacy":
                        # Legacy approach
                        quantum_instance = QuantumInstance(
                            self.backend, shots=self.shots)
                        self.shor_algorithm = Shor(quantum_instance=quantum_instance)

                logging.info(
                    f"[ATOM] ShorFactorization initialized with AerSimulator and shots={shots}.")

            except Exception as e:
                logging.error(f"Failed to initialize Qiskit backend: {e}")
                self.qiskit_ready = False
                self.backend = None
                self.shor_algorithm = None
        else:
            self.qiskit_ready = False
            self.backend = None
            self.shor_algorithm = None
            logging.warning(
                "[ATOM] ShorFactorization running in simulation mode (Qiskit unavailable)")

    def factorize(self, integer_to_factor: int) -> Dict[str, Any]:
        """
        [.] Executes Shor's algorithm to factor the given integer.

        Parameters:
            integer_to_factor (int): The integer to factorize.

        Returns:
            dict: Contains factors, success status, and quantum statistics.
        """
        logging.info(
            f"[SEARCH] Initiating factorization for integer: {integer_to_factor}")

        if integer_to_factor <= 1:
            logging.error("❌ Integer to factor must be greater than 1.")
            return {
                "success": False,
                "error": "Integer to factor must be greater than 1."
            }

        # Check if it's a small prime first
        if self._is_small_prime(integer_to_factor):
            return {
                "success": True,
                "factors": [[1, integer_to_factor]],
                "is_prime": True,
                "method": "classical_primality_test",
                "quantum_statistics": {
                    "backend": str(self.backend) if self.backend else "classical",
                    "shots": self.shots,
                    "successful_factorization": True
                }
            }

        # Try quantum factorization if available
        if self.qiskit_ready and SHOR_AVAILABLE and self.shor_algorithm:
            try:
                return self._quantum_factorize(integer_to_factor)
            except Exception as e:
                logging.warning(
                    f"Quantum factorization failed: {e}, falling back to classical")

        # Classical fallback
        return self._classical_factorize(integer_to_factor)

    def _quantum_factorize(self, n: int) -> Dict[str, Any]:
        """
        Perform quantum factorization using Shor's algorithm
        """
        try:
            # Execute Shor's Algorithm
            result = self.shor_algorithm.factor(n)

            if hasattr(result, 'factors') and result.factors:
                factors = [result.factors]  # Wrap in list for consistency
                logging.info(f"✅ Quantum factors found: {factors}")
                success = True
            else:
                logging.warning("[WARNING] Quantum algorithm did not find factors")
                factors = []
                success = False

            return {
                "success": success,
                "factors": factors,
                "method": f"shor_quantum_{SHOR_SOURCE}",
                "quantum_statistics": {
                    "backend": str(self.backend),
                    "shots": self.shots,
                    "successful_factorization": success,
                    "quantum_coherence": self.quantum_coherence,
                    "shor_source": SHOR_SOURCE
                }
            }

        except Exception as e:
            logging.error(f"Quantum factorization failed: {e}")
            # Fall back to classical implementation
            return self._classical_factorize(n)

    def _classical_factorize(self, n: int) -> Dict[str, Any]:
        """
        Classical factorization fallback using trial division
        """
        factors = []
        original_n = n

        # Handle factor 2
        while n % 2 == 0:
            factors.append(2)
            n //= 2

        # Check odd factors up to sqrt(n)
        i = 3
        while i * i <= n:
            while n % i == 0:
                factors.append(i)
                n //= i
            i += 2

        # If n is still > 1, then it's a prime factor
        if n > 1:
            factors.append(n)

        # Format as list of factors for consistency with quantum output
        factor_list = [factors] if factors else []

        logging.info(f"✅ Classical factors found: {factor_list}")

        return {
            "success": True,
            "factors": factor_list,
            "method": "classical_trial_division",
            "quantum_statistics": {
                "backend": "classical_simulation",
                "shots": self.shots,
                "successful_factorization": True
            }
        }

    def _is_small_prime(self, n: int, limit: int = 10000) -> bool:
        """
        Quick primality test for small numbers
        """
        if n < limit:
            if n < 2:
                return False
            if n == 2:
                return True
            if n % 2 == 0:
                return False

            for i in range(3, int(n**0.5) + 1, 2):
                if n % i == 0:
                    return False
            return True

        return False

    def validate_factors(self, integer: int, factors: list) -> bool:
        """
        🔎 Validates the provided factors by checking their product equals the original integer.

        Parameters:
            integer (int): The original integer.
            factors (list): List of potential factors.

        Returns:
            bool: Validation result.
        """
        if not factors:
            logging.warning("[WARNING] No factors provided for validation.")
            return False

        product = 1
        for factor_set in factors:
            for factor in factor_set:
                product *= factor

        is_valid = (product == integer)

        if is_valid:
            logging.info(
                f"✅ Factor validation successful: Product ({product}) matches integer ({integer}).")
        else:
            logging.warning(
                f"[WARNING] Factor validation failed: Product ({product}) does not match integer ({integer}).")

        return is_valid

    def get_status(self) -> Dict[str, Any]:
        """
        [CHART] Retrieves current status and configuration of Shor's algorithm module.

        Returns:
            dict: Status report.
        """
        status_report = {
            "algorithm": "Shor's Quantum Factorization",
            "backend": str(self.backend) if self.backend else "classical_simulation",
            "shots": self.shots,
            "qiskit_available": QISKIT_AVAILABLE,
            "shor_available": SHOR_AVAILABLE,
            "shor_source": SHOR_SOURCE,
            "quantum_ready": self.qiskit_ready,
            "quantum_coherence": self.quantum_coherence,
            "module_integrity": "optimal",
            "timestamp": datetime.now().isoformat()
        }
        logging.info(f"📌 Status Report: {status_report}")
        return status_report


# Utility function for quick factorization
def quick_factor(n: int) -> Dict[str, Any]:
    """
    Quick utility function for factorization

    Args:
        n: Integer to factor

    Returns:
        Factorization result
    """
    shor_module = ShorFactorization()
    return shor_module.factorize(n)


# Example usage and testing
if __name__ == "__main__":
    def test_factorization():
        """Test the factorization module"""
        shor = ShorFactorization()

        # Test cases
        test_numbers = [15, 21, 35, 77, 143]

        print("[SCOPE] Testing Shor's Factorization Module")
        print("=" * 50)

        for num in test_numbers:
            print(f"\n[CHART] Factoring {num}:")
            result = shor.factorize(num)

            if result.get("success", False):
                factors = result["factors"]
                method = result.get("method", "unknown")

                print(f"   Factors: {factors}")
                print(f"   Method: {method}")

                # Verify factorization
                if shor.validate_factors(num, factors):
                    print(f"   Verification: ✓ PASSED")
                else:
                    print(f"   Verification: ✗ FAILED")
            else:
                print(f"   Error: {result.get('error', 'Unknown error')}")

        # Print module status
        print(f"\n📈 Module Status:")
        status = shor.get_status()
        for key, value in status.items():
            print(f"   {key}: {value}")

    # Run test if executing directly
    test_factorization()
