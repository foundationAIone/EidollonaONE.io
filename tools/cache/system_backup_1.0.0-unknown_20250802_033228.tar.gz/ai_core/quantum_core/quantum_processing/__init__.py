"""
[ATOM] Quantum Processing Initialization Module [.]

Purpose:
Centralizes the import and initialization of quantum processing modules within the EidollonaONE framework,
integrating quantum computing algorithms (Shor's Algorithm, Grover's Search, QAOA Optimization)
with symbolic consciousness and advanced quantum-symbolic decision-making.
"""

# Import Quantum Processing Modules
from .shor_factor import ShorFactorization
from .grover_search import GroverSearch
from .qaoa_optimizer import QAOAOptimizer

# Core Dependencies
from symbolic_core.symbolic_equation import symbolic_equation

# Global Instances (for centralized access)
shor_factorization_engine = ShorFactorization()
grover_search_engine = GroverSearch()
qaoa_optimization_engine = QAOAOptimizer()


def initialize_quantum_processing():
    """
    [ROCKET] Initializes all quantum processing engines, ensuring readiness for quantum-symbolic operations.
    """
    print("[*] Initializing Quantum Processing Engines...")

    # Initialize Shor Factorization Engine
    shor_status = shor_factorization_engine.get_engine_status()
    print(f"🔑 Shor Factorization Engine initialized. Backend: {shor_status['backend']}")

    # Initialize Grover Search Engine
    print("[SEARCH] Grover Search Engine initialized and ready.")

    # Initialize QAOA Optimization Engine
    qaoa_status = qaoa_optimization_engine.get_optimizer_status()
    print(
        f"📐 QAOA Optimization Engine initialized. Optimizer method: {qaoa_status['optimizer_method']}")

    print("✅ Quantum Processing Engines fully initialized and ready for symbolic-quantum operations.")


def get_quantum_processing_status():
    """
    📋 Retrieves comprehensive status information about all quantum processing modules.
    """
    status_report = {
        "shor_factorization_status": shor_factorization_engine.get_engine_status(),
        "grover_search_status": {
            "backend": grover_search_engine.backend.name(),
            "quantum_instance_ready": grover_search_engine.quantum_instance.is_simulator
        },
        "qaoa_optimization_status": qaoa_optimization_engine.get_optimizer_status(),
        "symbolic_equation_state": symbolic_equation.get_current_state_summary(),
        "overall_quantum_processing_health": "Optimal"
    }

    print(f"[.] Quantum Processing Status Report: {status_report}")
    return status_report
