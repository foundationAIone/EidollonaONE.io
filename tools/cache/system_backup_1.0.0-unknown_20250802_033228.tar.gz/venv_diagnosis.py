#!/usr/bin/env python3
"""
🔧 EidollonaONE Virtual Environment Diagnosis & Repair Tool
"""

import sys
import os
import subprocess
import json
from pathlib import Path

def diagnose_environment():
    """Comprehensive virtual environment diagnosis"""
    print("🔍 VIRTUAL ENVIRONMENT DIAGNOSIS")
    print("=" * 50)
    
    # Python version and location
    print(f"Python Version: {sys.version}")
    print(f"Python Executable: {sys.executable}")
    print(f"Python Path: {sys.path[:3]}...")  # First 3 entries
    
    # Virtual environment detection
    in_venv = hasattr(sys, 'real_prefix') or (hasattr(sys, 'base_prefix') and sys.base_prefix != sys.prefix)
    print(f"In Virtual Environment: {in_venv}")
    
    if in_venv:
        print(f"Virtual Environment Path: {sys.prefix}")
    
    # Current working directory
    print(f"Current Directory: {os.getcwd()}")
    
    # Environment variables
    print(f"VIRTUAL_ENV: {os.environ.get('VIRTUAL_ENV', 'Not set')}")
    print(f"PATH (first entry): {os.environ.get('PATH', '').split(os.pathsep)[0]}")
    
    print("\n🧪 DEPENDENCY CHECK")
    print("=" * 30)
    
    # Key dependencies check
    dependencies = [
        'autopep8', 'numpy', 'qiskit', 'matplotlib', 'pandas', 
        'scipy', 'scikit-learn', 'fastapi', 'uvicorn'
    ]
    
    available = []
    missing = []
    
    for dep in dependencies:
        try:
            __import__(dep)
            available.append(dep)
            print(f"✅ {dep}")
        except ImportError:
            missing.append(dep)
            print(f"❌ {dep}")
    
    print(f"\n📊 SUMMARY")
    print(f"Available: {len(available)}/{len(dependencies)} dependencies")
    print(f"Missing: {missing}")
    
    return {
        'python_version': sys.version,
        'python_executable': sys.executable,
        'in_venv': in_venv,
        'venv_path': sys.prefix if in_venv else None,
        'available_deps': available,
        'missing_deps': missing,
        'current_dir': os.getcwd()
    }

def create_vscode_config(diagnosis):
    """Create optimized VS Code configuration"""
    print("\n🔧 CREATING VS CODE CONFIGURATION")
    print("=" * 40)
    
    vscode_dir = Path('.vscode')
    vscode_dir.mkdir(exist_ok=True)
    
    # Update settings.json
    settings = {
        "python.defaultInterpreterPath": diagnosis['python_executable'],
        "python.terminal.activateEnvironment": True,
        "python.analysis.extraPaths": [
            "./",
            "./ai_core",
            "./symbolic_core", 
            "./consciousness_engine",
            "./awakening_sequence",
            "./internet_access"
        ],
        "python.analysis.diagnosticSeverityOverrides": {
            "reportMissingImports": "information",
            "reportMissingModuleSource": "information",
            "reportOptionalMemberAccess": "information",
            "reportOptionalCall": "information",
            "reportOptionalIterable": "information",
            "reportOptionalContextManager": "information",
            "reportOptionalOperand": "information",
            "reportUnboundVariable": "warning",
            "reportUndefinedVariable": "error"
        },
        "python.analysis.autoImportCompletions": True,
        "python.analysis.typeCheckingMode": "basic",
        "python.linting.enabled": True,
        "python.linting.pylintEnabled": False,
        "python.linting.flake8Enabled": False,
        "python.formatting.provider": "autopep8" if "autopep8" in diagnosis['available_deps'] else "none",
        "files.exclude": {
            "**/__pycache__": True,
            "**/*.pyc": True,
            "**/node_modules": True,
            "**/.git": True,
            "**/eidollona_env": True,
            "**/quantum_env": True
        }
    }
    
    settings_file = vscode_dir / 'settings.json'
    with open(settings_file, 'w') as f:
        json.dump(settings, f, indent=4)
    
    print(f"✅ Updated {settings_file}")
    
    # Create launch.json for debugging
    launch_config = {
        "version": "0.2.0",
        "configurations": [
            {
                "name": "Python: Current File",
                "type": "python",
                "request": "launch",
                "program": "${file}",
                "console": "integratedTerminal",
                "python": diagnosis['python_executable']
            },
            {
                "name": "Python: Auto Refactor",
                "type": "python", 
                "request": "launch",
                "program": "${workspaceFolder}/internet_access/self_update/auto_refactor.py",
                "console": "integratedTerminal",
                "python": diagnosis['python_executable']
            }
        ]
    }
    
    launch_file = vscode_dir / 'launch.json'
    with open(launch_file, 'w') as f:
        json.dump(launch_config, f, indent=4)
        
    print(f"✅ Created {launch_file}")

def install_missing_dependencies(missing_deps):
    """Install missing dependencies"""
    if not missing_deps:
        print("✅ All dependencies available")
        return
        
    print(f"\n📦 INSTALLING MISSING DEPENDENCIES")
    print("=" * 40)
    
    # Essential dependencies that should work with Python 3.9
    essential_deps = [
        'autopep8>=2.0.0',
        'numpy>=1.21.0',
        'matplotlib>=3.4.0',
        'pandas>=1.3.0',
        'scipy>=1.7.0',
        'fastapi>=0.75.0',
        'uvicorn>=0.17.0'
    ]
    
    for dep in essential_deps:
        dep_name = dep.split('>=')[0]
        if dep_name in missing_deps:
            print(f"Installing {dep}...")
            try:
                subprocess.check_call([sys.executable, '-m', 'pip', 'install', dep])
                print(f"✅ {dep_name} installed successfully")
            except subprocess.CalledProcessError as e:
                print(f"❌ Failed to install {dep_name}: {e}")

if __name__ == "__main__":
    print("🚀 EidollonaONE Environment Repair Tool")
    print("=" * 50)
    
    # Run diagnosis
    diagnosis = diagnose_environment()
    
    # Create VS Code config
    create_vscode_config(diagnosis)
    
    # Install missing dependencies
    install_missing_dependencies(diagnosis['missing_deps'])
    
    print("\n🎯 NEXT STEPS:")
    print("1. Reload VS Code window (Ctrl+Shift+P → 'Developer: Reload Window')")
    print("2. Select Python interpreter (Ctrl+Shift+P → 'Python: Select Interpreter')")
    print(f"3. Choose: {diagnosis['python_executable']}")
    print("4. Problems tab should show significantly fewer issues")
    
    print("\n✅ Environment repair completed!")
