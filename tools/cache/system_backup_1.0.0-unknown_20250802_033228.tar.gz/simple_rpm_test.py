"""
Simple RPM Ecosystem Test for Diagnostic
"""

import sys
import os
from pathlib import Path

# Add avatar path for imports
avatar_path = Path(__file__).parent / "avatar"
if str(avatar_path) not in sys.path:
    sys.path.insert(0, str(avatar_path))

try:
    import rpm_ecosystem
    from rpm_ecosystem import EcosystemManager, AvatarConfig
    print("RPM ecosystem imports successful")
    print("Import test completed!")
    sys.exit(0)
except Exception as e:
    print("Import failed: {}".format(str(e)))
    sys.exit(1)
