/**
 * arms_relax_patch.js
 * Applies a relaxed arm swing profile with modest elbow flexion and reduced shoulder abduction.
 * Can be applied on top of your existing PoseLayers or ProceduralGait.
 */
import * as THREE from 'three';

export class ArmsRelaxPatch {
  constructor({ root, relax = 0.65 }){
    this.root = root;
    this.relax = relax;
    this.bones = {
      upperArmL: null, foreArmL: null, handL: null,
      upperArmR: null, foreArmR: null, handR: null,
      clavL: null, clavR: null
    };
    this._discover();
    this._t = 0;
  }
  _find(regex){
    let hit = null;
    this.root.traverse(o => { if (o.isBone && regex.test(o.name)) hit = o; });
    return hit;
  }
  _discover(){
    const rx = s => new RegExp(s, 'i');
    this.bones.upperArmL = this._find(rx('upper.?arm.*l|shoulder.*l'));
    this.bones.foreArmL  = this._find(rx('fore.?arm.*l|lower.?arm.*l'));
    this.bones.handL     = this._find(rx('hand.*l|wrist.*l'));
    this.bones.upperArmR = this._find(rx('upper.?arm.*r|shoulder.*r'));
    this.bones.foreArmR  = this._find(rx('fore.?arm.*r|lower.?arm.*r'));
    this.bones.handR     = this._find(rx('hand.*r|wrist.*r'));
    this.bones.clavL     = this._find(rx('clav|collar.*l'));
    this.bones.clavR     = this._find(rx('clav|collar.*r'));
  }
  update(dt, phase=0){
    this._t += dt;
    const s = Math.sin(phase * Math.PI * 2);
    const amp = 0.25 * this.relax; // radians
    const elbowFlex = 0.2 * this.relax;

    const L = this.bones, R = this.bones;
    if (L.upperArmL){ L.upperArmL.rotation.x = -amp * s; }
    if (L.foreArmL){  L.foreArmL.rotation.x  =  elbowFlex * Math.max(0, s); }
    if (L.upperArmR){ L.upperArmR.rotation.x =  amp * s; }
    if (L.foreArmR){  L.foreArmR.rotation.x  =  elbowFlex * Math.max(0, -s); }

    // Subtle clavicle depression for relaxed posture
    if (L.clavL) L.clavL.rotation.z = THREE.MathUtils.degToRad(-5 * this.relax);
    if (L.clavR) L.clavR.rotation.z = THREE.MathUtils.degToRad( 5 * this.relax);
  }
}
