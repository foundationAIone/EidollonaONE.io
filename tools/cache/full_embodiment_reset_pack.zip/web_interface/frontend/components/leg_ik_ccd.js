/**
 * leg_ik_ccd.js
 * Foot IK using three.js CCDIKSolver. Provides:
 *   - LegIK.fromHumanoid(root) to build CCDIK chains for L/R legs
 *   - solveFoot(side, pos, normal) to set per-frame targets and run solver.update()
 * Requires import map for three + addons:
 *   "three": ".../three.module.js", "three/addons/": ".../examples/jsm/"
 */
import * as THREE from 'three';
import { CCDIKSolver } from 'three/addons/animation/CCDIKSolver.js';

export class LegIK {
  constructor({ root, map }){
    this.root = root;
    this.map = map;
  this.mesh = null;        // SkinnedMesh
  this.skeleton = null;    // THREE.Skeleton
  this.targets = { L: null, R: null }; // target bones (toe or foot)
    this.iks = [];
    this.solver = null;
    this._fallback = false; // analytic fallback

    // Find a SkinnedMesh and its skeleton
  this.root.traverse(o=>{ if (!this.mesh && o.isSkinnedMesh && o.skeleton) this.mesh = o; });
    if (!this.mesh || !this.mesh.skeleton) {
      console.warn('[LegIK] No SkinnedMesh/skeleton found. Falling back to analytic 2-bone IK stub.');
      this._fallback = true;
      return;
    }
    this.skeleton = this.mesh.skeleton;

    const boneIndex = (bone)=> bone ? this.skeleton.bones.indexOf(bone) : -1;

    const tgtBoneL = this.map.toeL || this.map.footL;
    const tgtBoneR = this.map.toeR || this.map.footR;
    const effBoneL = this.map.footL;
    const effBoneR = this.map.footR;
    const linkShinL = this.map.shinL;
    const linkThighL = this.map.thighL;
    const linkShinR = this.map.shinR;
    const linkThighR = this.map.thighR;

    const makeLinks = (shin, thigh) => {
      const arr = [];
      const iShin = boneIndex(shin);
      const iThigh = boneIndex(thigh);
      if (iShin >= 0) arr.push({ index: iShin });
      if (iThigh >= 0) arr.push({ index: iThigh });
      return arr;
    };

    const chainL = (boneIndex(effBoneL) >= 0) ? {
      target: boneIndex(tgtBoneL),
      effector: boneIndex(effBoneL),
      links: makeLinks(linkShinL, linkThighL),
    } : null;
    const chainR = (boneIndex(effBoneR) >= 0) ? {
      target: boneIndex(tgtBoneR),
      effector: boneIndex(effBoneR),
      links: makeLinks(linkShinR, linkThighR),
    } : null;

    const iks = [];
    if (chainL && chainL.target >= 0) { iks.push(chainL); this.targets.L = this.skeleton.bones[chainL.target]; }
    if (chainR && chainR.target >= 0) { iks.push(chainR); this.targets.R = this.skeleton.bones[chainR.target]; }

    if (!iks.length) {
      console.warn('[LegIK] Could not build IK chains. Falling back to analytic 2-bone IK stub.');
      this._fallback = true;
      return;
    }

    this.iks = iks;
  this.solver = new CCDIKSolver(this.mesh, this.iks);
  }

  static async fromHumanoid(root){
    const { mapHumanoid } = await import('./humanoid_bone_map.js');
    const map = mapHumanoid(root);
    return new LegIK({ root, map });
  }

  solveFoot(side, worldPos, worldNormal){
    if (this._fallback) {
      // Minimal stub: no-op. You can extend with analytic IK if needed.
      return;
    }
    const tgtBone = (side==='L') ? this.targets.L : this.targets.R;
    if (!tgtBone) return;
    const parent = tgtBone.parent; if (!parent) return;
    const invParent = new THREE.Matrix4().copy(parent.matrixWorld).invert();
    const localPos = worldPos.clone().applyMatrix4(invParent);
    tgtBone.position.copy(localPos);
    if (worldNormal) {
      const up = new THREE.Vector3(0,1,0);
      const q = new THREE.Quaternion().setFromUnitVectors(up, worldNormal.clone().normalize());
      const parentInvQ = new THREE.Quaternion().copy(parent.getWorldQuaternion(new THREE.Quaternion())).invert();
      tgtBone.quaternion.copy(q.multiply(parentInvQ));
    }
  }

  update(){
    if (this._fallback) return;
    this.solver?.update();
  }
}
