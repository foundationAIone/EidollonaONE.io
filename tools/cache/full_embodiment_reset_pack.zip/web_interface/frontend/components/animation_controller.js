import * as THREE from 'three'
/**
 * animation_controller.js
 * Full-body animation orchestrator for GLTF avatars.
 * Dependencies: Three.js (THREE), GLTF with animations, optionally pose_layers and ik_solver.
 *
 * Usage (plain):
 *   import { AnimationOrchestrator } from '/frontend/components/animation_controller.js';
 *   const ac = new AnimationOrchestrator({ root: gltf.scene, clips: gltf.animations, scene, groundMeshes });
 *   ac.playLocomotion('idle');
 *   function animate(dt){ ac.update(dt); requestAnimationFrame(...); }
 *
 * Usage (R3F): create the orchestrator in useEffect after model loads; call update in useFrame.
 */

export class AnimationOrchestrator {
  constructor(opts = {}) {
    this.root = opts.root;                 // Object3D avatar root
    this.clips = opts.clips || [];         // Array<AnimationClip>
    this.scene = opts.scene || null;
    this.groundMeshes = opts.groundMeshes || []; // For foot IK raycast
    this.clockScale = 1.0;

    // Animation
  this.mixer = new THREE.AnimationMixer(this.root);
    this.actions = {};           // name -> AnimationAction
    this.named = {};             // semantic name -> AnimationAction
    this.currentBase = null;
    this.timeScaleByState = { idle: 1.0, walk: 1.0, run: 1.0, fly: 1.0 };

    this.lastState = 'idle';
    this.fade = 0.3;

    // Layers / add-ons
    this.layers = {
      additive: [], // e.g., breathing
      overlay: []   // upper-body gestures
    };

    // Optional hooks
    this.lipsyncEnergyFn = null; // function returning 0..1 energy
    this.pose = null;            // injected pose layer controller
    this.ik = null;              // injected IK controller

    this._buildActions();
  }

  _buildActions() {
    // Index all actions by clip name
    for (const clip of this.clips) {
      const act = this.mixer.clipAction(clip, this.root);
      act.enabled = true;
      act.setEffectiveWeight(0);
      act.setLoop(clip.name.toLowerCase().includes('once') ? THREE.LoopOnce : THREE.LoopRepeat, Infinity);
      act.clampWhenFinished = true;
      this.actions[clip.name] = act;
    }

    // Heuristic mapping by name patterns
    const sem = {
      idle: ['idle', 'rest', 'stand', 'breath'],
      walk: ['walk'],
      run:  ['run', 'jog'],
      turnLeft:  ['turnleft','turn_left','turn-l','turnl'],
      turnRight: ['turnright','turn_right','turn-r','turnr'],
      fly:  ['fly','glide'],
      gesture: ['gesture','wave','clap','bow','point']
    };
    const lowerNames = Object.keys(this.actions).map(n => [n, n.toLowerCase()]);

    const pick = (keys) => {
      for (const [original, lower] of lowerNames) {
        for (const k of keys) if (lower.includes(k)) return this.actions[original];
      }
      return null;
    };

    this.named.idle = pick(sem.idle);
    this.named.walk = pick(sem.walk);
    this.named.run  = pick(sem.run);
    this.named.turnLeft  = pick(sem.turnLeft);
    this.named.turnRight = pick(sem.turnRight);
    this.named.fly   = pick(sem.fly);
    // gesture(s): collect all that match
    this.named.gestures = lowerNames
      .filter(([orig, low]) => sem.gesture.some(k => low.includes(k)))
      .map(([orig]) => this.actions[orig]);

    // If nothing found, create a synthetic idle by pausing first clip
    if (!this.named.idle && this.clips.length) {
      const first = this.actions[this.clips[0].name];
      first.paused = true;
      this.named.idle = first;
    }
  }

  bindPoseLayer(poseController) {
    this.pose = poseController;
  }

  bindIK(ikController) {
    this.ik = ikController;
  }

  bindLipsyncEnergy(fn) {
    // fn should return 0..1 scalar indicating current mouth energy
    this.lipsyncEnergyFn = fn;
  }

  playLocomotion(state = 'idle', fade = this.fade) {
    const target = this.named[state];
    if (!target || this.currentBase === target) {
      this.lastState = state;
      return;
    }
    if (this.currentBase) {
      this.currentBase.crossFadeTo(target, fade, false);
    } else {
      target.reset().fadeIn(fade).play();
    }
    this.currentBase = target;
    this.lastState = state;
  }

  setState(state) {
    this.playLocomotion(state);
  }

  setSpeed(v) {
    this.setSpeedMetersPerSecond(v);
  }

  setSpeedMetersPerSecond(v) {
    // Choose locomotion clip and timeScale
    const spd = Math.max(0, v);
    let state = 'idle';
    if (spd < 0.1) state = 'idle';
    else if (spd < 1.8) state = 'walk';
    else state = 'run';
    this.playLocomotion(state);

    // timeScale heuristic
    const baseSpeed = state === 'walk' ? 1.2 : state === 'run' ? 3.5 : 1.0;
    const scale = state === 'idle' ? 1.0 : THREE.MathUtils.clamp(spd / baseSpeed, 0.5, 2.0);
    this.mixer.timeScale = scale * this.clockScale;
  }

  triggerGesture(index = 0, fade = 0.15, dur = 1.0) {
    if (!this.named.gestures || !this.named.gestures.length) return;
    const g = this.named.gestures[index % this.named.gestures.length];
    g.reset().setEffectiveWeight(1).fadeIn(fade).play();
    // schedule fade-out
    setTimeout(() => g.fadeOut(fade), Math.max(200, dur * 1000));
  }

  addAdditiveAction(clipName, weight = 0.3) {
    const act = this.actions[clipName];
    if (!act) return;
    if (typeof act.setEffectiveWeight === 'function') {
      act.setEffectiveWeight(weight);
    }
    // Mark as additive
    act.enabled = true;
    act.play();
    this.layers.additive.push({ action: act, weight });
  }

  update(dt) {
    // Update mixer
    this.mixer.update(dt);

    // Pose layers (breath, sway, head look, wings, hands)
    if (this.pose) {
      const energy = this.lipsyncEnergyFn ? this.lipsyncEnergyFn() : 0;
      this.pose.update(dt, { lipsyncEnergy: energy, locomotion: this.lastState });
    }

    // IK / foot placement
    if (this.ik) {
      this.ik.update(dt);
    }
  }
}
