/**
 * locomotion_engine.js
 * High-level gait engine that coordinates:
 *  - cadence & step length (speed = cadence * step_length)
 *  - narrow step width / "one-foot-in-front-of-the-other" (catwalk)
 *  - stride warping (match rig speed to predicted stride distance)
 *  - foot planting windows (stance ~60% of gait cycle)
 *  - delegates to FootLock & StrideWarp modules and calls provided IK
 *
 * Usage:
 *   import { LocomotionEngine } from './locomotion_engine.js';
 *   const engine = new LocomotionEngine({ rig, root, ik, groundMeshes, params });
 *   engine.setDesiredSpeed(1.2); // m/s
 *   // in frame loop:
 *   engine.update(dt);
 */
import * as THREE from 'three';
import { FootLock } from './foot_lock.js';
import { StrideWarp } from './stride_warp.js';

export class LocomotionEngine {
  constructor(opts){
    const {
      rig,           // THREE.Group moved through world
      root,          // avatar skinned root (gltf.scene) for bones
      ik=null,       // your IK instance with .solveFoot(side, target, normal)
      groundMeshes=[], // raycast surfaces
      params={}      // gait parameters (see defaults below)
    } = opts;
    this.rig = rig;
    this.root = root;
    this.ik = ik;
    this.groundMeshes = groundMeshes;
    this.params = Object.assign({
      // biomech-inspired defaults (can be tuned live)
      cadence_spm: 100,         // steps per minute (≈ 1.67 Hz) for elegant walk
      step_length_m: 0.70,      // meters per step (~70 cm normal adult step)
      step_width_m: 0.06,       // 6 cm line-walk (catwalk) default
      stance_ratio: 0.60,       // stance ~60% of gait cycle
      arms_relax: 0.65,         // 0..1 relax factor for arm swing (lower is relaxed)
      pelvis_bob_m: 0.03,       // vertical bob amplitude
      pelvis_yaw_rad: 0.10,     // gentle yaw
      lateral_sway_m: 0.02,     // side-to-side sway
      max_turn_slerp: 8.0,      // turning responsiveness
      min_speed: 0.0,
      max_speed: 2.0,
      use_ground_height: true,
    }, params);

    this.forward = new THREE.Vector3(0,0,1);
    this.right = new THREE.Vector3(1,0,0);
    this.up = new THREE.Vector3(0,1,0);

    this.clock = 0;
    this.phaseL = 0; // 0..1
    this.phaseR = 0.5; // out of phase
    this.speedMps = 0;    // current world speed (m/s)
    this.desiredSpeedMps = 1.2;

    // foot lock + stride warp helpers
    this.ray = new THREE.Raycaster();
    this._tmpV = new THREE.Vector3();
    this._tmpQ = new THREE.Quaternion();
    this._groundNormal = new THREE.Vector3(0,1,0);
    this._camFwd = new THREE.Vector3();

    this.foot = {
      L: new FootLock({ side:'L', stanceRatio: this.params.stance_ratio }),
      R: new FootLock({ side:'R', stanceRatio: this.params.stance_ratio }),
    };
    this.warp = new StrideWarp();
  }

  setDesiredSpeed(v){
    this.desiredSpeedMps = THREE.MathUtils.clamp(v, this.params.min_speed, this.params.max_speed);
  }
  setCadence(spm){ this.params.cadence_spm = spm; }
  setStepLength(m){ this.params.step_length_m = m; }
  setStepWidth(m){ this.params.step_width_m = m; }

  _groundAt(pos){
    if (!this.groundMeshes || !this.groundMeshes.length) return { y: pos.y, n: this._groundNormal.set(0,1,0) };
    this.ray.set(new THREE.Vector3(pos.x, pos.y + 2.0, pos.z), new THREE.Vector3(0,-1,0));
    const hits = this.ray.intersectObjects(this.groundMeshes, true);
    if (hits.length) return { y: hits[0].point.y, n: hits[0].face?.normal?.clone()?.transformDirection(hits[0].object.matrixWorld) || this._groundNormal.set(0,1,0) };
    return { y: pos.y, n: this._groundNormal.set(0,1,0) };
  }

  update(dt){
    // Smooth speed to desired, but keep it responsive
    this.speedMps += (this.desiredSpeedMps - this.speedMps) * Math.min(1, dt * 6.0);

    // cadence f (Hz) and phase advance per second
    const cadence_hz = (this.params.cadence_spm / 60.0);
    const phaseAdvance = cadence_hz * dt; // cycles per sec

    // Step frequency drives foot phases
    this.phaseL = (this.phaseL + phaseAdvance) % 1.0;
    this.phaseR = (this.phaseR + phaseAdvance) % 1.0;

    // Predict next stance windows (for foot planting) from stance_ratio ~60%
    const inStanceL = (this.phaseL < this.params.stance_ratio);
    const inStanceR = (this.phaseR < this.params.stance_ratio);

    // Desired forward delta this frame from cadence & step length
    const stepLen = this.params.step_length_m;
    const metersPerSec_fromCadence = cadence_hz * stepLen; // speed = cadence * step_length
    const predictedSpeed = metersPerSec_fromCadence;
    const blend = 0.5; // blend desired speed and cadence-derived speed
    const targetSpeed = THREE.MathUtils.lerp(this.speedMps, predictedSpeed, blend);

    // Apply stride warp: align rig translation with stance legs to reduce sliding
    const move = this.warp.computeDelta({
      dt, speed: targetSpeed, forward: this.forward, lateralSway: this.params.lateral_sway_m,
    });

    // Move rig forward and add slight pelvis bob
    this.rig.position.addScaledVector(move.forwardDir, move.forwardDist);
    this.rig.position.x += move.lateralOffset;

    // Headed direction
    const yaw = Math.atan2(move.forwardDir.x, move.forwardDir.z);
    this._tmpQ.setFromAxisAngle(this.up, yaw);
    this.rig.quaternion.slerp(this._tmpQ, Math.min(1, dt * this.params.max_turn_slerp));

    // Place feet: catwalk line = narrow step width
    const halfW = this.params.step_width_m * 0.5;
    const baseY = this.rig.position.y;
    const Lpos = new THREE.Vector3(-halfW, baseY, this.rig.position.z);
    const Rpos = new THREE.Vector3(+halfW, baseY, this.rig.position.z);

    // Project to ground height
    const gL = this._groundAt(Lpos), gR = this._groundAt(Rpos);
    Lpos.y = gL.y; Rpos.y = gR.y;

    // Update foot locks (locks during stance, free during swing; with foot roll)
    const footL = this.foot.L.update({ dt, worldPos: Lpos, groundN: gL.n, inStance: inStanceL });
    const footR = this.foot.R.update({ dt, worldPos: Rpos, groundN: gR.n, inStance: inStanceR });

    // Drive IK to the locked targets (if provided)
    if (this.ik && this.ik.solveFoot){
      this.ik.solveFoot('L', footL.pos, footL.n);
      this.ik.solveFoot('R', footR.pos, footR.n);
    }

    // Pelvis bob/yaw (on avatar root, not rig)
    const bob = this.params.pelvis_bob_m * (1 - Math.cos(2 * Math.PI * this.phaseL)) * 0.5;
    this.root.position.y = bob;
    this.root.rotation.y = Math.sin(2 * Math.PI * this.phaseL) * this.params.pelvis_yaw_rad;
  }
}
