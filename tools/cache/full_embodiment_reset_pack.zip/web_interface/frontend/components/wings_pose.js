// wings_pose.js
import * as THREE from 'three';
import { mapHumanoid } from './humanoid_bone_map.js';

export class WingsPose {
	constructor({ root, enabled=true }){
		this.root=root; this.enabled=enabled; this.map=mapHumanoid(root);
		this.t=0; this.amp=THREE.MathUtils.degToRad(12); this.speed=1.2;
	}
	update(dt){
		if (!this.enabled) return;
		this.t += dt*this.speed;
		const a = Math.sin(this.t)*this.amp;
		if (this.map.wingL) this.map.wingL.rotation.z = -a;
		if (this.map.wingR) this.map.wingR.rotation.z =  a;
	}
}
