/**
 * head_eyes_look.js
 * Smoothly orients head (and eyes, if present) toward a 3D target.
 * Includes a helper to attach to mouse ray on a ground plane or meshes.
 */
import * as THREE from 'three';

export class HeadEyesLook {
  constructor({ map, weight=0.8, eyeWeight=0.6, clampDeg=55, slerp=10 }){
    this.map = map;
    this.weight = weight;
    this.eyeWeight = eyeWeight;
    this.clamp = THREE.MathUtils.degToRad(clampDeg);
    this.slerp = slerp;
    this.target = new THREE.Vector3(0,1.6,2);
    this.tmpQ = new THREE.Quaternion();
    this.tmpV = new THREE.Vector3();
  }
  setTarget(v){ this.target.copy(v); }
  _applyBoneLook(bone, w){
    if (!bone) return;
    const from = new THREE.Vector3().setFromMatrixPosition(bone.matrixWorld);
    const dir = this.target.clone().sub(from);
    // clamp cone
    const fwd = new THREE.Vector3(0,0,1).applyQuaternion(bone.quaternion);
    const angle = fwd.angleTo(dir.clone().normalize());
    if (angle > this.clamp){
      // slerp direction toward clamp cone
      const axis = fwd.clone().cross(dir).normalize();
      const clamped = fwd.clone().applyAxisAngle(axis, this.clamp);
      dir.copy(clamped);
    }
    const q = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0,0,1), dir.normalize());
    bone.quaternion.slerp(q, Math.min(1, w));
  }
  update(dt){
    const k = Math.min(1, dt * this.slerp);
    this._applyBoneLook(this.map.head || this.map.neck, this.weight * k);
    if (this.map.eyeL) this._applyBoneLook(this.map.eyeL, this.eyeWeight * k);
    if (this.map.eyeR) this._applyBoneLook(this.map.eyeR, this.eyeWeight * k);
  }
}

export class MouseLookHelper {
  constructor({ camera, dom, look, rayMeshes=[], planeY=0 }){
    this.camera = camera; this.dom = dom; this.look = look;
    this.rayMeshes = rayMeshes; this.plane = new THREE.Plane(new THREE.Vector3(0,1,0), -planeY);
    this.ray = new THREE.Raycaster(); this.ndc = new THREE.Vector2();
    this.onMove = this.onMove.bind(this);
  }
  attach(){ this.dom.addEventListener('pointermove', this.onMove, { passive:true }); }
  detach(){ this.dom.removeEventListener('pointermove', this.onMove); }
  onMove(ev){
    const rect = this.dom.getBoundingClientRect();
    this.ndc.x = ((ev.clientX - rect.left) / rect.width) * 2 - 1;
    this.ndc.y = -((ev.clientY - rect.top) / rect.height) * 2 + 1;
    this.ray.setFromCamera(this.ndc, this.camera);
    let hitPoint = null;
    if (this.rayMeshes?.length){
      const hits = this.ray.intersectObjects(this.rayMeshes, true);
      if (hits.length) hitPoint = hits[0].point;
    }
    if (!hitPoint){
      const p = new THREE.Vector3();
      this.ray.ray.intersectPlane(this.plane, p);
      hitPoint = p;
    }
    this.look.setTarget(hitPoint);
  }
}
