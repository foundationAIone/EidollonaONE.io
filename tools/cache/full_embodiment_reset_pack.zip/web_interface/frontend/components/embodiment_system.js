import * as THREE from 'three'
import { ClothPBD } from './cloth_pbd.js'
import {
  applyRegalCatwalk,
  createCatwalkController
} from './supermodel_gait_patch.js'
import {
  autoPinsByBoneProximity,
  buildSimpleBodyCapsules,
  updateBodyColliders,
  findGarmentByName,
  repairAvatar,
  fixAlphaMaterials
} from './garment_bind.js'

/**
 * embodiment_system.js
 * Complete avatar embodiment system integrating gait, cloth, and rigging
 */

export class EmbodimentSystem {
  constructor(scene, camera, avatarRoot) {
    this.scene = scene
    this.camera = camera
    this.avatarRoot = avatarRoot

    // Subsystems
    this.clothSim = null
    this.gaits = new Map()
    this.colliders = []
    this.pins = []

    // Animation
    this.animationMixer = null
    this.catwalkController = null

    // Camera following
    this.cameraTarget = new THREE.Vector3()
    this.cameraOffset = new THREE.Vector3(0, 1.6, 3)
    this.followCamera = false

    // Debug
    this.debugMode = false
    this.debugLines = []

    console.log("🔮 EmbodimentSystem initialized")
  }

  initialize() {
    if (!this.avatarRoot) {
      console.warn("No avatar root provided")
      return false
    }

    // 1. Repair avatar rendering issues
    this.repairAvatarRendering()

    // 2. Setup animation mixer
    this.setupAnimationMixer()

    // 3. Setup cloth simulation
    this.setupClothSimulation()

    // 4. Enhance gait system
    this.enhanceGaitSystem()

    // 5. Setup camera following
    this.setupCameraFollowing()

    console.log("✨ Complete embodiment system activated")
    return true
  }

  repairAvatarRendering() {
    console.log("🔧 Repairing avatar rendering...")

    // Fix skinned mesh culling and materials
    repairAvatar(this.avatarRoot)
    fixAlphaMaterials(this.avatarRoot)

    // Separate head from body if needed
    this.separateHeadFromBody()

    console.log("✅ Avatar rendering repaired")
  }

  separateHeadFromBody() {
    // Find head bone and create separate render group
    let headBone = null
    let bodyRoot = null

    this.avatarRoot.traverse(obj => {
      if (obj.isBone) {
        if (/head|skull|cranium/i.test(obj.name)) {
          headBone = obj
        }
        if (/spine|chest|root|hips/i.test(obj.name) && !bodyRoot) {
          bodyRoot = obj
        }
      }
    })

    if (headBone && bodyRoot) {
      // Create render layers for separate animation
      this.avatarRoot.traverse(obj => {
        if (obj.isSkinnedMesh) {
          const isHeadMesh = obj.skeleton.bones.some(bone =>
            bone === headBone || headBone.children.includes(bone))

          obj.userData.renderGroup = isHeadMesh ? 'head' : 'body'
          obj.layers.set(isHeadMesh ? 1 : 0)
        }
      })

      console.log("🎭 Head/body separation complete")
    }
  }

  setupAnimationMixer() {
    this.animationMixer = new THREE.AnimationMixer(this.avatarRoot)

    // Find existing animations
    const clips = this.avatarRoot.animations || []
    if (clips.length > 0) {
      console.log(`🎬 Found ${clips.length} animation clips`)

      // Store animation actions
      this.animations = {}
      clips.forEach(clip => {
        this.animations[clip.name] = this.animationMixer.clipAction(clip)
      })
    }
  }

  setupClothSimulation() {
    // Find garment mesh
    const garment = findGarmentByName(this.scene, ['cloth', 'dress', 'top', 'cape', 'skirt'])
    if (!garment) {
      console.log("⚠️ No garment found for cloth simulation")
      return
    }

    console.log(`🧥 Setting up cloth simulation for: ${garment.name}`)

    // Create PBD cloth simulation
    this.clothSim = new ClothPBD(garment.geometry, {
      iterations: 8,
      damping: 0.95,
      gravity: new THREE.Vector3(0, -9.81, 0)
    })

    // Build body colliders
    const skeleton = this.findSkeleton()
    if (skeleton) {
      this.colliders = buildSimpleBodyCapsules(skeleton)
      this.clothSim.setColliders(this.colliders)

      // Auto-pin to bones
      this.pins = autoPinsByBoneProximity(garment, skeleton,
        ['shoulder', 'chest', 'spine', 'collar'], 0.08)

      this.pins.forEach(pin => {
        this.clothSim.addPin(pin.vertex, pin.offset)
      })

      console.log(`📌 Auto-pinned ${this.pins.length} vertices to bones`)
    }

    // Replace garment geometry with cloth simulation
    garment.geometry = this.clothSim.geometry
    garment.geometry.computeVertexNormals()
  }

  findSkeleton() {
    let skeleton = null
    this.avatarRoot.traverse(obj => {
      if (obj.isSkinnedMesh && obj.skeleton) {
        skeleton = obj.skeleton.bones[0] // Get root bone
        while (skeleton.parent && skeleton.parent.isBone) {
          skeleton = skeleton.parent
        }
      }
    })
    return skeleton
  }

  enhanceGaitSystem() {
    // Find gait-enabled objects
    this.avatarRoot.traverse(obj => {
      if (obj.userData.proceduralGait || obj.userData.gaitEnabled) {
        console.log(`👠 Enhancing gait for: ${obj.name}`)

        // Apply regal catwalk enhancement
        const gait = applyRegalCatwalk(obj.userData.proceduralGait || obj)
        this.gaits.set(obj.uuid, gait)

        // Create catwalk controller
        if (!this.catwalkController) {
          this.catwalkController = createCatwalkController()
        }
      }
    })

    if (this.gaits.size > 0) {
      console.log(`✨ Enhanced ${this.gaits.size} gait systems`)
    }
  }

  setupCameraFollowing() {
    // Calculate avatar center for camera targeting
    const box = new THREE.Box3().setFromObject(this.avatarRoot)
    this.cameraTarget.copy(box.getCenter(new THREE.Vector3()))
    this.cameraTarget.y = box.min.y + (box.max.y - box.min.y) * 0.6 // Chest height

    this.followCamera = true
    console.log("📹 Camera following enabled")
  }

  update(deltaTime) {
    // Update animation mixer
    if (this.animationMixer) {
      this.animationMixer.update(deltaTime)
    }

    // Update cloth simulation
    if (this.clothSim) {
      // Update collider positions
      updateBodyColliders(this.colliders)

      // Run cloth simulation
      this.clothSim.update(deltaTime)

      // Update vertex normals for lighting
      this.clothSim.geometry.computeVertexNormals()
    }

    // Update gait systems
    for (const gait of this.gaits.values()) {
      if (gait.update) {
        gait.update(deltaTime)
      }
    }

    // Update catwalk controller
    if (this.catwalkController) {
      this.catwalkController.update(deltaTime)
    }

    // Update camera following
    if (this.followCamera) {
      this.updateCameraFollowing(deltaTime)
    }
  }

  updateCameraFollowing(deltaTime) {
    // Get avatar root position
    const avatarPos = new THREE.Vector3()
    this.avatarRoot.getWorldPosition(avatarPos)

    // Smooth target following
    this.cameraTarget.lerp(avatarPos, deltaTime * 2.0)

    // Calculate desired camera position
    const desiredPos = this.cameraTarget.clone().add(this.cameraOffset)

    // Smooth camera movement
    this.camera.position.lerp(desiredPos, deltaTime * 1.5)
    this.camera.lookAt(this.cameraTarget)
  }

  // Control methods
  enableGait(enabled = true) {
    for (const gait of this.gaits.values()) {
      if (gait.setEnabled) {
        gait.setEnabled(enabled)
      }
    }
  }

  setCatwalkSpeed(speed = 1.2) {
    if (this.catwalkController) {
      this.catwalkController.setSpeed(speed)
    }
  }

  enableClothPhysics(enabled = true) {
    if (this.clothSim) {
      this.clothSim.enabled = enabled
    }
  }

  setCameraFollowing(enabled = true) {
    this.followCamera = enabled
  }

  // Debug visualization
  enableDebugMode(enabled = true) {
    this.debugMode = enabled

    if (enabled) {
      this.createDebugVisuals()
    } else {
      this.clearDebugVisuals()
    }
  }

  createDebugVisuals() {
    // Visualize cloth pins
    if (this.clothSim && this.pins.length > 0) {
      const pinGeometry = new THREE.SphereGeometry(0.01, 8, 6)
      const pinMaterial = new THREE.MeshBasicMaterial({ color: 0xff0000 })

      this.pins.forEach(pin => {
        const sphere = new THREE.Mesh(pinGeometry, pinMaterial)
        sphere.userData.debugType = 'clothPin'
        this.scene.add(sphere)
        this.debugLines.push(sphere)
      })
    }

    // Visualize body colliders
    this.colliders.forEach(collider => {
      if (collider.type === 'capsule') {
        const geometry = new THREE.CapsuleGeometry(collider.radius, collider.height)
        const material = new THREE.MeshBasicMaterial({
          color: 0x00ff00,
          wireframe: true,
          transparent: true,
          opacity: 0.3
        })
        const mesh = new THREE.Mesh(geometry, material)
        mesh.position.copy(collider.center)
        mesh.userData.debugType = 'collider'
        this.scene.add(mesh)
        this.debugLines.push(mesh)
      }
    })

    console.log("🔍 Debug visualizations enabled")
  }

  clearDebugVisuals() {
    this.debugLines.forEach(obj => {
      this.scene.remove(obj)
      obj.geometry?.dispose()
      obj.material?.dispose()
    })
    this.debugLines = []
  }

  dispose() {
    // Cleanup resources
    this.clearDebugVisuals()

    if (this.clothSim) {
      this.clothSim.dispose()
    }

    if (this.animationMixer) {
      this.animationMixer.stopAllAction()
    }

    console.log("🧹 EmbodimentSystem disposed")
  }
}
