/**
 * humanoid_bone_map.js
 * Walks a SkinnedMesh hierarchy to discover common humanoid bones by regex.
 * Returns a normalized map usable by the IK and head-look controllers.
 */
export function mapHumanoid(root){
  const rx = (s)=> new RegExp(s, 'i');
  const find = (patterns)=>{
    let hit=null;
    root.traverse(o=>{
      if (hit || !o.isBone) return;
      for (const p of patterns){ if (p.test(o.name)) { hit=o; break; } }
    });
    return hit;
  };
  const map = {
    hips: find([rx('^Hips$'), rx('pelvis'), rx('hip(?!.*(l|r))'), rx('root')]),
    spine: find([rx('^Spine$'), rx('spine(?!.*\\d)|spine1|spine01|chest')]),
    chest: find([rx('chest|spine2|upper.?chest')]),
    neck: find([rx('^Neck'), rx('neck')]),
    head: find([rx('^Head'), rx('head')]),
    eyeL: find([rx('eye.*l|l.*eye')]),
    eyeR: find([rx('eye.*r|r.*eye')]),

    // Arms
    clavL: find([rx('clav|collar.*l|shoulder.*base.*l')]),
    clavR: find([rx('clav|collar.*r|shoulder.*base.*r')]),
    upperArmL: find([rx('upper.?arm.*l|shoulder(?!.*base).*l|arm.*up.*l')]),
    upperArmR: find([rx('upper.?arm.*r|shoulder(?!.*base).*r|arm.*up.*r')]),
    foreArmL:  find([rx('fore.?arm.*l|lower.?arm.*l')]),
    foreArmR:  find([rx('fore.?arm.*r|lower.?arm.*r')]),
    handL:     find([rx('hand.*l|wrist.*l')]),
    handR:     find([rx('hand.*r|wrist.*r')]),

    // Legs
    thighL: find([rx('thigh.*l|upper.?leg.*l|hip.*l|upleg.*l|LeftUpLeg')]),
    thighR: find([rx('thigh.*r|upper.?leg.*r|hip.*r|upleg.*r|RightUpLeg')]),
    shinL:  find([rx('calf.*l|lower.?leg.*l|shin.*l|knee.*l|LeftLeg')]),
    shinR:  find([rx('calf.*r|lower.?leg.*r|shin.*r|knee.*r|RightLeg')]),
    footL:  find([rx('foot.*l|ankle.*l|LeftFoot')]),
    footR:  find([rx('foot.*r|ankle.*r|RightFoot')]),
    toeL:   find([rx('toe.*l|ball.*l|LeftToe')]),
    toeR:   find([rx('toe.*r|ball.*r|RightToe')]),
  };
  return map;
}
