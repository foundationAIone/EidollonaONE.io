import * as THREE from 'three'

/**
 * garment_bind.js
 * Utilities for auto-pinning cloth vertices to skeleton bones and building body colliders
 */

export function autoPinsByBoneProximity(garmentMesh, skeletonRoot, boneNames = [], threshold = 0.06) {
  if (!garmentMesh || !garmentMesh.geometry || !skeletonRoot) return []

  const pins = []
  const bones = {}

  // Find bones by name
  skeletonRoot.traverse(obj => {
    if (obj.isBone && boneNames.some(name =>
      obj.name.toLowerCase().includes(name.toLowerCase()))) {
      bones[obj.name] = obj
    }
  })

  if (Object.keys(bones).length === 0) return pins

  const posAttr = garmentMesh.geometry.getAttribute('position')
  if (!posAttr) return pins

  // Transform vertices to world space for distance calculations
  const worldMatrix = garmentMesh.matrixWorld

  for (let i = 0; i < posAttr.count; i++) {
    const vertex = new THREE.Vector3()
    vertex.fromBufferAttribute(posAttr, i)
    vertex.applyMatrix4(worldMatrix)

    // Find closest bone within threshold
    let closestBone = null
    let minDistance = threshold

    for (const [boneName, bone] of Object.entries(bones)) {
      if (!bone.matrixWorld) continue

      const bonePos = new THREE.Vector3()
      bonePos.setFromMatrixPosition(bone.matrixWorld)

      const distance = vertex.distanceTo(bonePos)
      if (distance < minDistance) {
        minDistance = distance
        closestBone = bone
      }
    }

    if (closestBone) {
      const bonePos = new THREE.Vector3()
      bonePos.setFromMatrixPosition(closestBone.matrixWorld)
      const offset = vertex.clone().sub(bonePos)

      pins.push({
        vertex: i,
        bone: closestBone,
        offset: offset,
        distance: minDistance
      })
    }
  }

  return pins
}

export function buildSimpleBodyCapsules(skeletonRoot) {
  const colliders = []
  const bones = {}

  // Common bone name patterns for body parts
  const bodyBones = {
    spine: /spine|chest|back/i,
    pelvis: /hips|pelvis|root/i,
    thigh: /thigh|upper.*leg|hip/i,
    shin: /calf|lower.*leg|shin|knee/i,
    upperArm: /upper.*arm|shoulder|arm.*up/i,
    foreArm: /fore.*arm|lower.*arm|elbow/i
  }

  // Collect bones
  skeletonRoot.traverse(obj => {
    if (!obj.isBone) return

    for (const [category, pattern] of Object.entries(bodyBones)) {
      if (pattern.test(obj.name)) {
        if (!bones[category]) bones[category] = []
        bones[category].push(obj)
      }
    }
  })

  // Build colliders for major body segments
  const createCapsule = (bone, radius, height) => {
    if (!bone || !bone.matrixWorld) return null

    const center = new THREE.Vector3()
    center.setFromMatrixPosition(bone.matrixWorld)

    return {
      type: 'capsule',
      center,
      radius,
      height,
      bone // Keep reference for updates
    }
  }

  // Torso (spine/chest)
  if (bones.spine && bones.spine.length > 0) {
    const spine = bones.spine[0]
    const collider = createCapsule(spine, 0.15, 0.6)
    if (collider) colliders.push(collider)
  }

  // Pelvis
  if (bones.pelvis && bones.pelvis.length > 0) {
    const pelvis = bones.pelvis[0]
    const collider = createCapsule(pelvis, 0.12, 0.3)
    if (collider) colliders.push(collider)
  }

  // Thighs
  if (bones.thigh) {
    bones.thigh.forEach(thigh => {
      const collider = createCapsule(thigh, 0.08, 0.4)
      if (collider) colliders.push(collider)
    })
  }

  // Upper arms
  if (bones.upperArm) {
    bones.upperArm.forEach(arm => {
      const collider = createCapsule(arm, 0.06, 0.3)
      if (collider) colliders.push(collider)
    })
  }

  return colliders
}

export function updateBodyColliders(colliders) {
  // Update collider positions based on current bone transforms
  for (const collider of colliders) {
    if (collider.bone && collider.bone.matrixWorld) {
      collider.center.setFromMatrixPosition(collider.bone.matrixWorld)
    }
  }
}

export function findGarmentByName(scene, patterns = ['cloth', 'garment', 'top', 'dress', 'cape', 'skirt']) {
  let garment = null

  scene.traverse(obj => {
    if (obj.isMesh && obj.geometry && patterns.some(pattern =>
      obj.name.toLowerCase().includes(pattern.toLowerCase()))) {
      garment = obj
    }
  })

  return garment
}

export function repairAvatar(root) {
  // Fix common skinned mesh rendering issues
  root.traverse(obj => {
    if (obj.isSkinnedMesh) {
      // Disable frustum culling for animated meshes (incorrect bounds)
      obj.frustumCulled = false
      obj.castShadow = true
      obj.receiveShadow = true
    }

    if (obj.isMesh) {
      obj.castShadow = true
      obj.receiveShadow = true
    }
  })
}

export function fixAlphaMaterials(root) {
  // Fix transparent materials that should use alpha test instead of blending
  root.traverse(obj => {
    const materials = obj.material ?
      (Array.isArray(obj.material) ? obj.material : [obj.material]) : []

    for (const material of materials) {
      if (!material) continue

      // Convert full opacity transparent materials to alpha test
      if (material.transparent && material.opacity === 1 && !material.alphaMap) {
        material.alphaTest = 0.5
        material.transparent = false
        material.needsUpdate = true
      }

      // Ensure proper depth writing
      if (material.transparent) {
        material.depthWrite = false
      } else {
        material.depthWrite = true
      }
    }
  })
}
