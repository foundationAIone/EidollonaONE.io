/**
 * leg_ik_2bone.js
 * Wrapper providing solveFoot('L'|'R', pos, normal) + update() using TwoBoneIKLeg.
 * Requires the humanoid mapper to find thigh/shin/foot bones.
 */
import * as THREE from 'three';
import { TwoBoneIKLeg } from './two_bone_ik.js';
import { mapHumanoid } from './humanoid_bone_map.js';

export class LegIK2Bone {
  constructor({ root, poleHintL = new THREE.Vector3(0,0,1), poleHintR = new THREE.Vector3(0,0,1) }){
    this.root = root;
    this.map = mapHumanoid(root);
    this.legL = null; this.legR = null;
    // Build legs if possible
    if (this.map.thighL && this.map.shinL && this.map.footL){
      this.legL = new TwoBoneIKLeg({ thigh: this.map.thighL, shin: this.map.shinL, foot: this.map.footL, poleHint: poleHintL });
      this.legL.calibrateFromCurrentPose();
    }
    if (this.map.thighR && this.map.shinR && this.map.footR){
      this.legR = new TwoBoneIKLeg({ thigh: this.map.thighR, shin: this.map.shinR, foot: this.map.footR, poleHint: poleHintR });
      this.legR.calibrateFromCurrentPose();
    }
    this.targets = { L: { p: null, n: null }, R: { p: null, n: null } };
  }
  solveFoot(side, worldPos, worldNormal){
    const key = side === 'L' ? 'L' : 'R';
    this.targets[key].p = worldPos ? worldPos.clone() : null;
    this.targets[key].n = worldNormal ? worldNormal.clone() : null;
  }
  update(){
    if (this.legL && this.targets.L.p) this.legL.solveTo(this.targets.L.p, this.targets.L.n);
    if (this.legR && this.targets.R.p) this.legR.solveTo(this.targets.R.p, this.targets.R.n);
  }
}
