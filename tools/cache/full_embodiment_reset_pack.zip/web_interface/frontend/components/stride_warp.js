/**
 * stride_warp.js
 * Predicts the correct forward distance per frame from speed to reduce foot sliding.
 * Adds a small lateral sway to hint at single support.
 */
import * as THREE from 'three';

export class StrideWarp {
  constructor(){
    this._dir = new THREE.Vector3(0,0,1);
    this._lat = 0;
    this._t = 0;
  }
  computeDelta({ dt, speed, forward = new THREE.Vector3(0,0,1), lateralSway = 0.02 }){
    this._t += dt;
    this._dir.copy(forward).normalize();
    const forwardDist = Math.max(0, speed) * dt;
    // gentle sine sway left/right
    this._lat = Math.sin(this._t * Math.PI * 2.0) * lateralSway;
    return { forwardDir: this._dir, forwardDist, lateralOffset: this._lat };
  }
}
