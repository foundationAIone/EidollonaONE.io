(function (global) {
  class LipsyncController {
    constructor(options = {}) {
      this.root = null;
      this.meshes = [];
      this.visemeMap = options.visemeMap || {};
      this.morphIntensity = {};
      this.smoothing = options.smoothing ?? 0.25;
      this.decay = options.decay ?? 4.0;
      this.silenceFloor = options.silenceFloor ?? 0.01;
      this.rmsCap = options.rmsCap ?? 0.16;
      this.active = false;

      this.ctx = null;
      this.analyser = null;
      this.timeBuf = null;
      this.freqBuf = null;
      this.sampleRate = 48000;
      this.sourceNode = null;

      this.jawBone = null;
      this.jawRange = options.jawRange ?? { min: 0, max: 0.28 };

  // Exposed read-only energy (0..1) for downstream pose layers
  this.energy = 0;
    }

    bindToRoot(rootObject3D) {
      this.root = rootObject3D;
      this.meshes = [];
      this.jawBone = null;

      rootObject3D.traverse((o) => {
        if (o.isMesh && o.morphTargetDictionary && o.morphTargetInfluences) {
          this.meshes.push(o);
        }
        if (!this.jawBone && o.isBone && /jaw/i.test(o.name)) {
          this.jawBone = o;
        }
      });

      for (const name of Object.keys(this.visemeMap)) {
        this.morphIntensity[name] = 0;
      }
    }

    async connectMicrophone() {
      this.ctx = new (window.AudioContext || window.webkitAudioContext)();
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const src = this.ctx.createMediaStreamSource(stream);
      this._initAnalyser(src);
      this.active = true;
    }

    connectAudioElement(audioEl) {
      this.ctx = new (window.AudioContext || window.webkitAudioContext)();
      const src = this.ctx.createMediaElementSource(audioEl);
      src.connect(this.ctx.destination);
      this._initAnalyser(src);
      this.active = true;
    }

    _initAnalyser(src) {
      this.analyser = this.ctx.createAnalyser();
      this.analyser.fftSize = 2048;
      this.sampleRate = this.ctx.sampleRate;
      src.connect(this.analyser);
      this.timeBuf = new Float32Array(this.analyser.fftSize);
      this.freqBuf = new Uint8Array(this.analyser.frequencyBinCount);
    }

    update(dt) {
      if (!this.active || !this.analyser) return;

      this.analyser.getFloatTimeDomainData(this.timeBuf);
      this.analyser.getByteFrequencyData(this.freqBuf);

      let sum = 0;
      for (let i = 0; i < this.timeBuf.length; i++) {
        const v = this.timeBuf[i];
        sum += v * v;
      }
      const rms = Math.sqrt(sum / this.timeBuf.length);

      let wSum = 0, fSum = 0;
      for (let i = 0; i < this.freqBuf.length; i++) {
        const w = this.freqBuf[i];
        wSum += w;
        fSum += w * i;
      }
      const centroidBin = fSum / Math.max(wSum, 1e-6);
      const centroidHz = (centroidBin * this.sampleRate) / (2 * this.freqBuf.length);

      let viseme = "sil";
      if (rms > this.silenceFloor) {
        if (centroidHz < 800) viseme = "aa";
        else if (centroidHz < 1500) viseme = "E";
        else if (centroidHz < 2600) viseme = "SS";
        else viseme = "FF";
      }

  const open = this._clamp((rms - this.silenceFloor) / (this.rmsCap - this.silenceFloor), 0, 1);
  this.energy = open;

      this._decayAll(dt);
      this._applyViseme(viseme, open);
      this._writeMorphs();
      this._driveJawFallback(open);
    }

    _decayAll(dt) {
      for (const key of Object.keys(this.morphIntensity)) {
        const v = this.morphIntensity[key] || 0;
        const decayed = v * Math.exp(-this.decay * dt);
        this.morphIntensity[key] = decayed;
      }
    }

    _applyViseme(name, intensity) {
      if (!this.visemeMap[name]) return;
      const target = intensity;
      const current = this.morphIntensity[name] || 0;
      const next = this._lerp(current, target, this.smoothing);
      this.morphIntensity[name] = next;

      if (name === "aa") this._bump("oh", next * 0.2);
      if (name === "E")  this._bump("PP", next * 0.1);
      if (name === "FF") this._bump("TH", next * 0.2);
    }

    _bump(name, add) {
      const cur = this.morphIntensity[name] || 0;
      const tgt = this._clamp(cur + add, 0, 1);
      this.morphIntensity[name] = this._lerp(cur, tgt, this.smoothing);
    }

    _writeMorphs() {
      for (const mesh of this.meshes) {
        const K = mesh.morphTargetInfluences.length;
        for (let i = 0; i < K; i++) {
          mesh.morphTargetInfluences[i] *= 0.85;
        }
      }

      for (const [name, weight] of Object.entries(this.morphIntensity)) {
        const targets = this.visemeMap[name] || [];
        for (const tName of targets) {
          for (const mesh of this.meshes) {
            const dict = mesh.morphTargetDictionary;
            if (!dict) continue;
            const idx = dict[tName];
            if (idx !== undefined) {
              const cur = mesh.morphTargetInfluences[idx] || 0;
              mesh.morphTargetInfluences[idx] = this._lerp(cur, weight, this.smoothing);
            }
          }
        }
      }
    }

    _driveJawFallback(open) {
      if (!this.jawBone || this.meshes.length > 0) return;
      const r = this.jawRange.min + (this.jawRange.max - this.jawRange.min) * open;
      this.jawBone.rotation.x = this._lerp(this.jawBone.rotation.x, r, this.smoothing);
    }

    _lerp(a, b, t) { return a + (b - a) * t; }
    _clamp(x, lo, hi) { return Math.max(lo, Math.min(hi, x)); }
  }

  global.LipsyncController = LipsyncController;
})(window);
