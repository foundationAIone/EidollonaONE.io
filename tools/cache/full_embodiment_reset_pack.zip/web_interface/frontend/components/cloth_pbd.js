import * as THREE from 'three'

/**
 * cloth_pbd.js
 * Position-Based Dynamics cloth simulation for real-time garment physics
 * - Unconditionally stable at interactive timesteps
 * - Operates directly on mesh vertex positions
 * - Supports pins, collisions, and skeletal binding
 */

export class ClothPBD {
  constructor({ mesh, skeletonRoot, pins = [], colliders = [], params = {} }) {
    this.mesh = mesh
    this.skeletonRoot = skeletonRoot
    this.pins = pins
    this.colliders = colliders

    // PBD parameters
    this.params = {
      iterations: 10,
      gravity: new THREE.Vector3(0, -9.81, 0),
      damping: 0.98,
      stretch: 1.0,
      bend: 0.1,
      collision: 0.05,
      ...params
    }

    this.enabled = true
    this.initialized = false
    this.positions = []
    this.prevPositions = []
    this.velocities = []
    this.constraints = []

    this._initializeCloth()
  }

  _initializeCloth() {
    if (!this.mesh || !this.mesh.geometry) return

    const geometry = this.mesh.geometry
    const posAttr = geometry.getAttribute('position')
    if (!posAttr) return

    const vertexCount = posAttr.count
    this.positions = []
    this.prevPositions = []
    this.velocities = []

    // Initialize particle positions from mesh vertices
    for (let i = 0; i < vertexCount; i++) {
      const pos = new THREE.Vector3()
      pos.fromBufferAttribute(posAttr, i)

      // Transform to world space
      pos.applyMatrix4(this.mesh.matrixWorld)

      this.positions[i] = pos.clone()
      this.prevPositions[i] = pos.clone()
      this.velocities[i] = new THREE.Vector3()
    }

    this._buildConstraints()
    this.initialized = true
  }

  _buildConstraints() {
    if (!this.mesh.geometry.index) return

    const indices = this.mesh.geometry.index.array
    const edges = new Set()

    // Build stretch constraints from triangle edges
    for (let i = 0; i < indices.length; i += 3) {
      const a = indices[i]
      const b = indices[i + 1]
      const c = indices[i + 2]

      // Add edges (avoid duplicates)
      this._addEdge(edges, a, b)
      this._addEdge(edges, b, c)
      this._addEdge(edges, c, a)
    }

    // Convert edges to distance constraints
    for (const edgeKey of edges) {
      const [a, b] = edgeKey.split('-').map(Number)
      const restLength = this.positions[a].distanceTo(this.positions[b])

      this.constraints.push({
        type: 'distance',
        a, b,
        restLength,
        stiffness: this.params.stretch
      })
    }
  }

  _addEdge(edges, a, b) {
    const key = a < b ? `${a}-${b}` : `${b}-${a}`
    edges.add(key)
  }

  update(dt) {
    if (!this.enabled || !this.initialized || dt <= 0) return

    const positions = this.positions
    const prevPositions = this.prevPositions
    const velocities = this.velocities

    // Verlet integration
    for (let i = 0; i < positions.length; i++) {
      if (this._isPinned(i)) continue

      // Calculate velocity
      velocities[i].subVectors(positions[i], prevPositions[i]).divideScalar(dt)

      // Store current position as previous
      prevPositions[i].copy(positions[i])

      // Apply gravity and damping
      velocities[i].add(this.params.gravity.clone().multiplyScalar(dt))
      velocities[i].multiplyScalar(this.params.damping)

      // Update position
      positions[i].add(velocities[i].clone().multiplyScalar(dt))
    }

    // Constraint solving iterations
    for (let iter = 0; iter < this.params.iterations; iter++) {
      this._solveConstraints()
      this._solveCollisions()
      this._solvePins()
    }

    // Update mesh geometry
    this._updateMeshPositions()
  }

  _isPinned(vertexIndex) {
    return this.pins.some(pin => pin.vertex === vertexIndex)
  }

  _solveConstraints() {
    for (const constraint of this.constraints) {
      if (constraint.type === 'distance') {
        this._solveDistanceConstraint(constraint)
      }
    }
  }

  _solveDistanceConstraint(constraint) {
    const { a, b, restLength, stiffness } = constraint
    const pos1 = this.positions[a]
    const pos2 = this.positions[b]

    const delta = pos2.clone().sub(pos1)
    const currentLength = delta.length()

    if (currentLength === 0) return

    const difference = (currentLength - restLength) / currentLength
    const correction = delta.multiplyScalar(difference * stiffness * 0.5)

    if (!this._isPinned(a)) pos1.add(correction)
    if (!this._isPinned(b)) pos2.sub(correction)
  }

  _solveCollisions() {
    for (let i = 0; i < this.positions.length; i++) {
      if (this._isPinned(i)) continue

      for (const collider of this.colliders) {
        this._solveCollision(i, collider)
      }
    }
  }

  _solveCollision(vertexIndex, collider) {
    const pos = this.positions[vertexIndex]
    const { center, radius, height } = collider

    if (collider.type === 'capsule') {
      // Simple capsule collision (cylinder with rounded ends)
      const localPos = pos.clone().sub(center)
      const halfHeight = height * 0.5

      // Clamp Y to cylinder height
      const clampedY = Math.max(-halfHeight, Math.min(halfHeight, localPos.y))
      const cylCenter = new THREE.Vector3(0, clampedY, 0)

      const radialDir = localPos.clone().sub(cylCenter)
      radialDir.y = 0 // project to XZ plane
      const radialDist = radialDir.length()

      if (radialDist < radius + this.params.collision) {
        radialDir.normalize()
        const correction = radialDir.multiplyScalar(radius + this.params.collision - radialDist)
        pos.add(correction)
      }
    }
  }

  _solvePins() {
    for (const pin of this.pins) {
      const { vertex, bone, offset = new THREE.Vector3() } = pin

      if (bone && bone.matrixWorld) {
        // Pin to bone position
        const bonePos = new THREE.Vector3()
        bonePos.setFromMatrixPosition(bone.matrixWorld)
        bonePos.add(offset)

        this.positions[vertex].copy(bonePos)
      }
    }
  }

  _updateMeshPositions() {
    if (!this.mesh.geometry) return

    const posAttr = this.mesh.geometry.getAttribute('position')
    if (!posAttr) return

    const invMatrix = this.mesh.matrixWorld.clone().invert()

    for (let i = 0; i < this.positions.length; i++) {
      const localPos = this.positions[i].clone().applyMatrix4(invMatrix)
      posAttr.setXYZ(i, localPos.x, localPos.y, localPos.z)
    }

    posAttr.needsUpdate = true
    this.mesh.geometry.computeVertexNormals()
  }

  setEnabled(enabled) {
    this.enabled = enabled
  }

  addPin(vertexIndex, bone, offset) {
    this.pins.push({ vertex: vertexIndex, bone, offset })
  }

  removePin(vertexIndex) {
    this.pins = this.pins.filter(pin => pin.vertex !== vertexIndex)
  }
}
