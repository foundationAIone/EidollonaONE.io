import * as THREE from 'three'

/**
 * supermodel_gait_patch.js
 * Applies regal catwalk styling to ProceduralGait for elegant runway motion
 * - Longer stride length, narrow step width with crossover
 * - Controlled arm swing, composed posture
 * - Speed ≈ 1.2 m/s, cadence ≈ 1.3-1.6 Hz for elegant pace
 */

export function applyRegalCatwalk(gait) {
  if (!gait || typeof gait.update !== 'function') return

  // Store original update method
  const originalUpdate = gait.update.bind(gait)

  // Enhanced gait parameters for catwalk style
  gait.style = 'standard'
  gait.catwalkParams = {
    strideLength: 1.4,      // longer steps for elegance
    stepWidth: 0.08,        // narrow, slight crossover
    armSwingScale: 0.6,     // reduced arm motion for composure
    pelvisSwayScale: 1.2,   // subtle hip sway
    spineCounterScale: 0.8, // reduced counter-rotation
    cadenceScale: 0.85,     // slower, more deliberate
    postureUpright: 0.1     // slight backward lean for poise
  }

  gait.setStyle = function(styleName) {
    this.style = styleName
    if (styleName === 'regalCatwalk') {
      // Activate catwalk parameters
      this.enabled = true
    }
  }

  // Override update with catwalk enhancements
  gait.update = function(dt) {
    if (!this.enabled || !this.root) return

    const speed = this.getSpeed()
    const isClip = this.getIsPlayingClip()

    // When real locomotion clip is active, blend out procedural
    const targetIntensity = isClip ? 0 : Math.max(0, Math.min(1, speed / 1.6))
    this.intensity += (targetIntensity - this.intensity) * Math.min(1, dt * 6.0)

    if (this.intensity < 0.01) return

    // Apply catwalk styling if active
    const isRegal = this.style === 'regalCatwalk'
    const params = isRegal ? this.catwalkParams : {
      strideLength: 1.0, stepWidth: 0.15, armSwingScale: 1.0,
      pelvisSwayScale: 1.0, spineCounterScale: 1.0, cadenceScale: 1.0, postureUpright: 0
    }

    // Adjusted step frequency for elegance
    const baseStepHz = 1.2 + 0.6 * Math.min(1.5, speed / 1.3)
    const stepHz = baseStepHz * params.cadenceScale
    this.phase += dt * stepHz * Math.PI * 2
    const s0 = Math.sin(this.phase)
    const c0 = Math.cos(this.phase)

    // Enhanced amplitudes with catwalk scaling
    const hipFlex = 0.40 * this.intensity * params.strideLength
    const kneeBend = 0.65 * this.intensity
    const anklePitch = 0.25 * this.intensity
    const armSwing = 0.35 * this.intensity * params.armSwingScale
    const pelvisBob = 0.03 * this.intensity
    const pelvisYaw = 0.08 * this.intensity * params.pelvisSwayScale
    const spineCounter = 0.06 * this.intensity * params.spineCounterScale

    // Catwalk-specific: narrow step width with slight crossover
    const stepWidth = params.stepWidth
    const postureOffset = params.postureUpright

    const applyLeg = (thigh, shin, foot, phaseSign) => {
      if (!thigh || !shin) return
      const s = Math.sin(this.phase * phaseSign)
      const c = Math.cos(this.phase * phaseSign)

      // Forward/back swing with stride length scaling
      thigh.rotation.x = hipFlex * s + postureOffset

      // Knee bend during swing phase
      shin.rotation.x = Math.max(0, kneeBend * Math.max(0, -s))

      // Ankle pitch with elegant roll
      if (foot) foot.rotation.x = anklePitch * (-s * 0.5 + c * 0.5)

      // Catwalk crossover: slight inward step
      if (isRegal && thigh.parent) {
        const crossover = stepWidth * Math.sin(this.phase * phaseSign * 0.5) * phaseSign
        thigh.parent.position.z = crossover * this.intensity
      }
    }

    const applyArm = (upper, fore, phaseSign) => {
      if (!upper) return
      const s = Math.sin(this.phase * phaseSign)

      // Reduced arm swing for composure
      upper.rotation.x = armSwing * (-s)
      if (fore) fore.rotation.x = armSwing * Math.max(0, s * 0.4) // less forearm bend
    }

    // Enhanced pelvis motion for catwalk
    if (this.bones.pelvis) {
      this.bones.pelvis.position.y = pelvisBob * (1 - c0*c0) // smooth bounce
      this.bones.pelvis.rotation.y = pelvisYaw * s0 // hip sway

      // Catwalk posture: slight backward lean
      if (isRegal) {
        this.bones.pelvis.rotation.x = postureOffset * this.intensity
      }
    }

    if (this.bones.spine) {
      this.bones.spine.rotation.y = -spineCounter * s0 // counter-rotation
      if (isRegal) {
        // Subtle spine extension for poise
        this.bones.spine.rotation.x = postureOffset * 0.5 * this.intensity
      }
    }

    // Apply to legs with opposite phases for alternating steps
    applyLeg(this.bones.thighL, this.bones.shinL, this.bones.footL, +1)
    applyLeg(this.bones.thighR, this.bones.shinR, this.bones.footR, -1)

    // Arms swing opposite to legs (reduced for catwalk)
    applyArm(this.bones.upperArmL, this.bones.foreArmL, -1)
    applyArm(this.bones.upperArmR, this.bones.foreArmR, +1)
  }
}

export function createCatwalkController({ rig, speed = 1.2, points = [] }) {
  return {
    speed,
    points: points.length ? points : [
      new THREE.Vector3(0, 0, -2),
      new THREE.Vector3(0, 0, 2)
    ],
    currentTarget: 0,
    forward: true,

    update(dt) {
      if (!rig || this.points.length < 2) return

      const target = this.points[this.currentTarget]
      const dir = target.clone().sub(rig.position)
      const dist = dir.length()

      if (dist < 0.05) {
        // Reached target, switch direction
        this.forward = !this.forward
        this.currentTarget = this.forward ? 1 : 0
        return
      }

      // Move toward target with elegant pace
      dir.normalize()
      rig.position.addScaledVector(dir, this.speed * dt)

      // Face movement direction with smooth rotation
      const yaw = Math.atan2(dir.x, dir.z)
      const targetQuat = new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 1, 0), yaw)
      rig.quaternion.slerp(targetQuat, Math.min(1, dt * 8))

      return this.speed
    }
  }
}
