/**
 * debug_foot_markers.js
 * Visualizes foot lock targets in world space.
 */
import * as THREE from 'three';
export class DebugFootMarkers {
  constructor(scene){
    this.scene = scene;
    const matL = new THREE.MeshBasicMaterial({ color: 0x66ccff });
    const matR = new THREE.MeshBasicMaterial({ color: 0xff6699 });
    const geo = new THREE.SphereGeometry(0.03, 12, 12);
    this.markerL = new THREE.Mesh(geo, matL);
    this.markerR = new THREE.Mesh(geo, matR);
    scene.add(this.markerL, this.markerR);
  }
  update(posL, posR){
    if (posL) this.markerL.position.copy(posL);
    if (posR) this.markerR.position.copy(posR);
  }
}
