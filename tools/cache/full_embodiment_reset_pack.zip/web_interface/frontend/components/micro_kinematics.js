// micro_kinematics.js
import * as THREE from 'three';

// Adds subtle, continuous motion to spine/neck/shoulders/hands/fingers/ankles/toes.
// Driven by gait phase from LocomotionEngine and optional lipsync energy (0..1).
export class MicroKinematics {
  constructor({ root, engine, lipsyncEnergyRef=null }){
    this.root = root;
    this.engine = engine;
    this.e = { lips: lipsyncEnergyRef }; // function or null
    this.b = {};
    this._findBones();
    this.t = 0;
    this._tmp = new THREE.Vector3();
  }
  _f(rx){ let h=null; this.root.traverse(o=>{ if(!h && o.isBone && rx.test(o.name||'')) h=o; }); return h; }
  _findBones(){
    const rx = s => new RegExp(s,'i');
    // Spine/neck/head
    this.b.spine = this._f(rx('^spine$|spine(?!.*\\d)|spine1|chest'));
    this.b.chest = this._f(rx('chest|upper.?chest|spine2'));
    this.b.neck  = this._f(rx('^neck|neck'));
    this.b.head  = this._f(rx('^head|head'));
    // Clavicles/arms
    this.b.clavL = this._f(rx('clav|collar.*l'));
    this.b.clavR = this._f(rx('clav|collar.*r'));
    this.b.uArmL = this._f(rx('upper.?arm.*l|shoulder(?!.*base).*l'));
    this.b.uArmR = this._f(rx('upper.?arm.*r|shoulder(?!.*base).*r'));
    this.b.fArmL = this._f(rx('fore.?arm.*l|lower.?arm.*l'));
    this.b.fArmR = this._f(rx('fore.?arm.*r|lower.?arm.*r'));
    // Hands
    this.b.handL = this._f(rx('hand.*l|wrist.*l'));
    this.b.handR = this._f(rx('hand.*r|wrist.*r'));
    // Ankles/toes
    this.b.ankleL= this._f(rx('ankle.*l|foot.*l|LeftFoot'));
    this.b.ankleR= this._f(rx('ankle.*r|foot.*r|RightFoot'));
    this.b.toeL  = this._f(rx('toe.*l|ball.*l|LeftToe'));
    this.b.toeR  = this._f(rx('toe.*r|ball.*r|RightToe'));
  }
  update(dt){
    if (!dt) return;
    this.t += dt;
    const phase = (this.engine && typeof this.engine.phaseL === 'number') ? this.engine.phaseL : (this.t % 1.0);
    const s = Math.sin(phase*2*Math.PI), c = Math.cos(phase*2*Math.PI);

    // Spine/chest counter-rotation + slight pitch
    if (this.b.spine) this.b.spine.rotation.y = 0.04 * s;
    if (this.b.chest) this.b.chest.rotation.y = -0.04 * s;
    if (this.b.spine) this.b.spine.rotation.x = 0.02 * c;

    // Neck micro (keep subtle so head-look remains primary)
    if (this.b.neck)  this.b.neck.rotation.x += 0.01 * Math.sin(this.t*3.1);

    // Clavicles — slight elevation/depression
    if (this.b.clavL) this.b.clavL.rotation.z = THREE.MathUtils.degToRad(-5) + 0.02 * c;
    if (this.b.clavR) this.b.clavR.rotation.z = THREE.MathUtils.degToRad( 5) - 0.02 * c;

    // Hands/fingers — flex with arm swing; add small voice coupling
    const speak = this.e.lips ? Math.min(1, (typeof this.e.lips === 'function' ? this.e.lips() : 0)*1.5) : 0;
    const handFlexL = 0.15*Math.max(0, s) + 0.10*speak;
    const handFlexR = 0.15*Math.max(0,-s) + 0.10*speak;
    this._fanFingerFlex(this.b.handL, handFlexL);
    this._fanFingerFlex(this.b.handR, handFlexR);

    // Ankles & toes — dorsiflex during swing, plantarflex at toe-off
    if (this.b.ankleL) this.b.ankleL.rotation.x =  0.20*Math.max(0,-s) - 0.10*Math.max(0, s);
    if (this.b.ankleR) this.b.ankleR.rotation.x = -0.20*Math.max(0, s) + 0.10*Math.max(0,-s);
    if (this.b.toeL)   this.b.toeL.rotation.x   =  0.15*Math.max(0, s);
    if (this.b.toeR)   this.b.toeR.rotation.x   =  0.15*Math.max(0,-s);
  }
  _fanFingerFlex(hand, amt){
    if (!hand) return;
    const rx = n=>new RegExp(n,'i');
    const names = ['Index','Middle','Ring','Pinky','Thumb'];
    for (const n of names){
      let base=null;
      hand.traverse(o=>{ if(!base && o.isBone && rx(n).test(o.name||'')) base=o; });
      if (!base) continue;
      base.traverse(o=>{ if(o.isBone) o.rotation.x = -amt; });
    }
  }
}
