/**
 * two_bone_ik.js
 * Analytic two-bone IK (hip/thigh -> knee/shin -> ankle/foot).
 * Works in WORLD space and writes LOCAL quaternions back to bones.
 *
 * Usage:
 *   const leg = new TwoBoneIKLeg({ thigh, shin, foot, poleHint: new THREE.Vector3(0,0,1) });
 *   leg.calibrateFromCurrentPose();  // measure lengths & initial directions
 *   leg.solveTo(targetWorldPos, targetNormal /* optional */);  // sets bone quaternions
 */
import * as THREE from 'three';

export class TwoBoneIKLeg {
  constructor({ thigh, shin, foot, poleHint = new THREE.Vector3(0,0,1) }){
    this.thigh = thigh; this.shin = shin; this.foot = foot;
    this.poleHint = poleHint.clone().normalize();
    this._tmp = {
      vA: new THREE.Vector3(), vB: new THREE.Vector3(), vC: new THREE.Vector3(),
      u: new THREE.Vector3(), v: new THREE.Vector3(), w: new THREE.Vector3(),
      q: new THREE.Quaternion(), q2: new THREE.Quaternion(),
      m: new THREE.Matrix4(), inv: new THREE.Matrix4()
    };
    this.len1 = 0; this.len2 = 0;
    this.eps = 1e-5;
  }

  _worldPos(b){ return new THREE.Vector3().setFromMatrixPosition(b.matrixWorld); }
  _worldQuat(b){ const q = new THREE.Quaternion(); b.getWorldQuaternion(q); return q; }
  _parentWorldQuat(b){ const q = new THREE.Quaternion(); (b.parent||b).getWorldQuaternion(q); return q; }

  calibrateFromCurrentPose(){
    const a = this._worldPos(this.thigh);
    const b = this._worldPos(this.shin);
    const c = this._worldPos(this.foot);
    this.len1 = a.distanceTo(b);
    this.len2 = b.distanceTo(c);
    if (!isFinite(this.len1) || !isFinite(this.len2) || this.len1 < this.eps || this.len2 < this.eps){
      // Fallback to reasonable defaults
      this.len1 = this.len1 || 0.45;
      this.len2 = this.len2 || 0.45;
    }
  }

  /**
   * Solve the leg toward target world position. Optional foot normal will align ankle pitch.
   * Writes LOCAL bone quaternions on thigh & shin; leaves foot rotation mostly as-is.
   */
  solveTo(targetWorld, footNormal=null){
    const t = this._tmp;
    const hipW = this._worldPos(this.thigh);
    const kneeW = this._worldPos(this.shin);
    const ankleW = this._worldPos(this.foot);

    // Distances
    const dirToTarget = t.vA.copy(targetWorld).sub(hipW);
    let d = dirToTarget.length();
    const maxReach = this.len1 + this.len2 - 1e-4;
    const minReach = Math.abs(this.len1 - this.len2) + 1e-4;
    d = THREE.MathUtils.clamp(d, minReach, maxReach);

    // Plane of the leg: use poleHint to pick knee direction (avoid flipping)
    const forward = dirToTarget.normalize();
    const pole = t.vB.copy(this.poleHint).normalize();
    // Orthonormal basis for the leg plane
    const side = t.vC.copy(forward).cross(pole).normalize();
    const up = t.vA.copy(side).cross(forward).normalize(); // "knee" direction

    // Law of cosines for knee angle (angle at the knee)
    const cosKnee = THREE.MathUtils.clamp((this.len1*this.len1 + this.len2*this.len2 - d*d) / (2*this.len1*this.len2), -1, 1);
    const kneeAngle = Math.PI - Math.acos(cosKnee);

    // Hip angle (angle at hip between thigh and target)
    const cosHip = THREE.MathUtils.clamp((this.len1*this.len1 + d*d - this.len2*this.len2) / (2*this.len1*d), -1, 1);
    const hipAngle = Math.acos(cosHip);

    // Desired knee world position (along forward from hip, then offset slightly by "up"):
    const kneeTarget = hipW.clone().add(forward.clone().multiplyScalar(this.len1)).add(up.clone().multiplyScalar(0.0001));

    // --- Orient THIGH so that its child axis points toward kneeTarget
    const thighParentQ = this._parentWorldQuat(this.thigh);
    const thighWorldQ = this._worldQuat(this.thigh);
    const thighDirNow = this._worldPos(this.shin).sub(hipW).normalize();
    const thighDirGoal = kneeTarget.clone().sub(hipW).normalize();
    const rotThigh = t.q.setFromUnitVectors(thighDirNow, thighDirGoal);
    const thighWorldQGoal = rotThigh.multiply(thighWorldQ);
    const thighLocalQ = thighParentQ.clone().invert().multiply(thighWorldQGoal);
    this.thigh.quaternion.copy(thighLocalQ);

    // --- Orient SHIN by rotating around knee so ankle reaches target (kneeAngle)
    // After updating thigh, recompute knee & ankle world
    this.thigh.updateMatrixWorld(true);
    const hipW2 = this._worldPos(this.thigh);
    const kneeW2 = this._worldPos(this.shin);
    const shinParentQ = this._parentWorldQuat(this.shin);
    const shinWorldQ = this._worldQuat(this.shin);
    const shinDirNow = this._worldPos(this.foot).sub(kneeW2).normalize();

    // desired shin direction approximately points to target
    const shinDirGoal = targetWorld.clone().sub(kneeW2).normalize();
    const rotShinAim = t.q2.setFromUnitVectors(shinDirNow, shinDirGoal);
    const shinWorldQGoalAim = rotShinAim.multiply(shinWorldQ);

    // additionally bend to satisfy kneeAngle by rotating around the "side" axis of the leg plane
    // Build a rotation quaternion about the plane's side axis
    const kneeBendQ = new THREE.Quaternion().setFromAxisAngle(side, kneeAngle - shinDirNow.angleTo(shinDirGoal));
    const shinWorldQGoal = kneeBendQ.multiply(shinWorldQGoalAim);

    const shinLocalQ = shinParentQ.clone().invert().multiply(shinWorldQGoal);
    this.shin.quaternion.copy(shinLocalQ);

    // --- Optionally orient FOOT to ground normal (pitch/roll only, keep yaw from rig)
    if (footNormal){
      // align foot's local up (y) to the ground normal in world
      const footParentQ = this._parentWorldQuat(this.foot);
      const footWorldQ = this._worldQuat(this.foot);
      const upNow = new THREE.Vector3(0,1,0).applyQuaternion(footWorldQ);
      const qAlign = new THREE.Quaternion().setFromUnitVectors(upNow.normalize(), footNormal.clone().normalize());
      const footWorldQGoal = qAlign.multiply(footWorldQ);
      const footLocalQ = footParentQ.clone().invert().multiply(footWorldQGoal);
      this.foot.quaternion.copy(footLocalQ);
    }
  }
}
