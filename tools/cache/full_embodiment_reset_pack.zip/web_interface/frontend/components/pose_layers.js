/**
 * pose_layers.js
 * Procedural additive layers for full-body life: breathing, gaze, head look, eye blink, hand/fingers, wings.
 * All layers are optional and auto-discover bones/morphs by regex when possible.
 */
import * as THREE from 'three'

export class PoseLayers {
  constructor(opts = {}) {
    this.root = opts.root;
    this.scene = opts.scene;
    this.time = 0;

    // Bone refs
    this.bones = {
      spine: null, chest: null, neck: null, head: null,
      eyes: { left: null, right: null },
      wings: { left: null, right: null },
      hands: { left: {}, right: {} }
    };

    // Eye blink morphs (fallback to bones if absent)
    this.eyeMorphs = { left: null, right: null }; // [mesh, index]

    // Params
    this.breath = { amp: 0.02, speed: 0.18 }; // meters / Hz ~ 0.18 Hz
    this.sway = { amp: 0.02, speed: 0.55 };
    this.head = { lookAt: null, weight: 0.65, maxYaw: 35 * Math.PI/180, maxPitch: 20 * Math.PI/180 };
    this.blink = { probPerSec: 0.2, dur: 0.12, t: 0, closing: false, val: 0 };
    this.hands = { curl: 0.1, spread: 0.02 };
    this.wings = { amp: 0.35, speed: 1.2 };

    this._discover();
  }

  _discover() {
    const find = (regex) => {
      let f = null;
      this.root.traverse(o => { if (o.isBone && regex.test(o.name)) f = o; });
      return f;
    };
    this.bones.spine = find(/spine(?!.*\d)/i) || find(/spine.*1/i);
    this.bones.chest = find(/spine.*2|chest/i) || this.bones.spine;
    this.bones.neck  = find(/neck/i);
    this.bones.head  = find(/head/i);

    // Eyes: bones or morphs
    this.bones.eyes.left  = find(/eye.*l/i);
    this.bones.eyes.right = find(/eye.*r/i);

    // Wings
    this.bones.wings.left  = find(/wing.*l/i);
    this.bones.wings.right = find(/wing.*r/i);

    // Eye blink morphs trial
    const blinkKeys = [/blink.*l/i, /blink.*r/i, /eye.*close.*l/i, /eye.*close.*r/i];
    this.root.traverse(o => {
      if (o.isMesh && o.morphTargetDictionary) {
        const dict = o.morphTargetDictionary;
        const keys = Object.keys(dict);
        for (const k of keys) {
          if (!this.eyeMorphs.left && blinkKeys[0].test(k)) this.eyeMorphs.left  = [o, dict[k]];
          if (!this.eyeMorphs.right && blinkKeys[1].test(k)) this.eyeMorphs.right = [o, dict[k]];
        }
      }
    });

    // Hands ~ basic finger bones (heuristic)
    const addFinger = (side, finger, regexes) => {
      this.bones.hands[side][finger] = [];
      this.root.traverse(o => {
        if (o.isBone && regexes.some(r => r.test(o.name))) this.bones.hands[side][finger].push(o);
      });
      // sort proximal->distal-ish by name length
      this.bones.hands[side][finger].sort((a,b)=>a.name.length-b.name.length);
    };
    const rx = (n) => new RegExp(n, 'i');
    addFinger('left', 'thumb',  [rx('thumb.*l'), rx('th.*l')]);
    addFinger('left', 'index',  [rx('index.*l'), rx('pointer.*l')]);
    addFinger('left', 'middle', [rx('middle.*l')]);
    addFinger('left', 'ring',   [rx('ring.*l')]);
    addFinger('left', 'pinky',  [rx('pinky.*l'), rx('little.*l')]);
    addFinger('right','thumb',  [rx('thumb.*r'), rx('th.*r')]);
    addFinger('right','index',  [rx('index.*r'), rx('pointer.*r')]);
    addFinger('right','middle', [rx('middle.*r')]);
    addFinger('right','ring',   [rx('ring.*r')]);
    addFinger('right','pinky',  [rx('pinky.*r'), rx('little.*r')]);
  }

  setHeadLookTarget(obj3DOrVector) {
    this.head.lookAt = obj3DOrVector;
  }

  _applyBreathing(dt) {
    const t = this.time * this.breath.speed * 2 * Math.PI;
    const y = Math.sin(t) * this.breath.amp;
    if (this.bones.chest) this.bones.chest.position.y = y;
  }

  _applySway(dt) {
    const t = this.time * this.sway.speed * 2 * Math.PI;
    const r = Math.sin(t) * this.sway.amp;
    if (this.bones.spine) this.bones.spine.rotation.z = r * 0.4;
    if (this.bones.spine) this.bones.spine.rotation.x = r * 0.2;
  }

  _applyHeadLook(dt) {
    if (!this.bones.head || !this.head.lookAt) return;
    const head = this.bones.head;
    const target = (this.head.lookAt.isVector3)
      ? this.head.lookAt
      : this.head.lookAt.getWorldPosition(new THREE.Vector3());

    const headPos = head.getWorldPosition(new THREE.Vector3());
    const to = target.clone().sub(headPos).normalize();
    const yaw = Math.atan2(to.x, to.z);
    const pitch = Math.asin(THREE.MathUtils.clamp(to.y, -1, 1));

    head.rotation.y = THREE.MathUtils.clamp(yaw * this.head.weight, -this.head.maxYaw, this.head.maxYaw);
    head.rotation.x = THREE.MathUtils.clamp(-pitch * this.head.weight, -this.head.maxPitch, this.head.maxPitch);
  }

  _applyBlink(dt) {
    // stochastic blinking
    this.blink.t += dt;
    if (!this.blink.closing && Math.random() < this.blink.probPerSec * dt) {
      this.blink.closing = true; this.blink.t = 0;
    }
    if (this.blink.closing) {
      this.blink.val = Math.min(1, this.blink.t / this.blink.dur);
      if (this.blink.val >= 1) { this.blink.closing = false; this.blink.t = 0; }
    } else if (this.blink.val > 0) {
      this.blink.val = Math.max(0, 1 - (this.blink.t / this.blink.dur));
      if (this.blink.val <= 0) this.blink.t = 0;
    }

    const setBlink = (side, v) => {
      const m = this.eyeMorphs[side];
      if (m) {
        const [mesh, idx] = m;
        mesh.morphTargetInfluences[idx] = v;
      } else if (this.bones.eyes[side]) {
        this.bones.eyes[side].rotation.x = v * 0.2; // bone fallback
      }
    };
    setBlink('left', this.blink.val);
    setBlink('right', this.blink.val);
  }

  _applyHands(dt) {
    const curl = this.hands.curl;
    const spread = this.hands.spread;

    const applyChain = (chain, sign=1) => {
      if (!chain) return;
      for (let i=0; i<chain.length; i++) {
        const b = chain[i];
        if (!b) continue;
        if (i === 0) { b.rotation.y = sign * spread; }
        b.rotation.x = 0.3 * curl * (i+1);
      }
    };

    for (const side of ['left','right']) {
      for (const finger of Object.keys(this.bones.hands[side])) {
        applyChain(this.bones.hands[side][finger], side === 'left' ? 1 : -1);
      }
    }
  }

  _applyWings(dt, locomotion) {
    if (!this.bones.wings.left && !this.bones.wings.right) return;
    const t = this.time * this.wings.speed * 2 * Math.PI;
    const a = this.wings.amp * (locomotion === 'fly' ? 1.0 : 0.35);
    const rot = Math.sin(t) * a;
    if (this.bones.wings.left)  this.bones.wings.left.rotation.z  =  rot;
    if (this.bones.wings.right) this.bones.wings.right.rotation.z = -rot;
  }

  update(dt, ctx = {}) {
    this.time += dt;
    const energy = ctx.lipsyncEnergy || 0;
    const locomotion = ctx.locomotion || 'idle';

    // Slight head bob from energy, if any
    if (this.bones.head) this.bones.head.rotation.z = (energy * 0.08) * Math.sin(this.time * 8.0);

    this._applyBreathing(dt);
    this._applySway(dt);
    this._applyHeadLook(dt);
    this._applyBlink(dt);
    this._applyHands(dt);
    this._applyWings(dt, locomotion);
  }
}
