import * as THREE from 'three'
/**
 * ik_solver.js
 * Minimal IK & Foot Placement utilities (FABRIK-like for 2-bone chains).
 * Assumes standard humanoid legs/arms naming, but allows explicit binding.
 *
 * Usage:
 *   const ik = new FootIK({ root, scene, groundMeshes, leftLeg: {...}, rightLeg: {...} });
 *   in tick: ik.update(dt);
 */

export class FootIK {
  constructor(opts = {}) {
    this.root = opts.root;
    this.scene = opts.scene;
    this.groundMeshes = opts.groundMeshes || [];
    this.enabled = true;

    // Leg chains: each has { hip, knee, ankle, foot }
    this.left = opts.leftLeg || null;
    this.right = opts.rightLeg || null;

    // Params
    this.rayMax = opts.rayMax || 3.0;
    this.footOffset = opts.footOffset || 0.02;
    this.smooth = opts.smooth || 0.35;

  this._raycaster = new THREE.Raycaster();
  this._down = new THREE.Vector3(0, -1, 0);
    this._tmp = {
      v: new THREE.Vector3(),
      a: new THREE.Vector3(),
      b: new THREE.Vector3(),
      c: new THREE.Vector3()
    };
  }

  static fromHumanoid(root, scene, groundMeshes) {
    // Try to auto-detect bones by common names
    const find = (regex) => {
      let found = null;
      root.traverse(o => {
        if (o.isBone && regex.test(o.name)) found = o;
      });
      return found;
    };
    const left = {
      hip:   find(/thigh.*l|hip.*l|upperleg.*l/i),
      knee:  find(/calf.*l|knee.*l|lowerleg.*l/i),
      ankle: find(/ankle.*l/i),
      foot:  find(/foot.*l/i)
    };
    const right = {
      hip:   find(/thigh.*r|hip.*r|upperleg.*r/i),
      knee:  find(/calf.*r|knee.*r|lowerleg.*r/i),
      ankle: find(/ankle.*r/i),
      foot:  find(/foot.*r/i)
    };
    return new FootIK({ root, scene, groundMeshes, leftLeg: left, rightLeg: right });
  }

  _raycastFootTarget(worldPos) {
    this._raycaster.set(worldPos, this._down);
    const hits = this._raycaster.intersectObjects(this.groundMeshes, true);
    if (hits.length) {
      const p = hits[0].point.clone();
      p.y += this.footOffset;
      return p;
    }
    // fallback: keep original
    return worldPos;
  }

  _solveTwoBone(hip, knee, ankle, target) {
    // FABRIK-like for a planar two-bone chain
    hip.updateWorldMatrix(true, false);
    knee.updateWorldMatrix(true, false);
    ankle.updateWorldMatrix(true, false);

    const a = hip.getWorldPosition(this._tmp.a);
    const b = knee.getWorldPosition(this._tmp.b);
    const c = ankle.getWorldPosition(this._tmp.c);

    const ab = a.distanceTo(b);
    const bc = b.distanceTo(c);

    // Direction from hip to target
    const dir = target.clone().sub(a);
    const len = dir.length();
    if (len < 1e-5) return;

    // Law of cosines for knee angle
    const clamp = (x, lo, hi) => Math.max(lo, Math.min(hi, x));
    const cosKnee = clamp((ab*ab + bc*bc - len*len) / (2*ab*bc), -1, 1);
    const kneeAngle = Math.acos(cosKnee);

    // Re-orient plane using current hip->knee->ankle
    const basisZ = dir.clone().normalize();
    const basisX = new THREE.Vector3().subVectors(b, a).cross(new THREE.Vector3().subVectors(c, b)).normalize();
    const basisY = new THREE.Vector3().crossVectors(basisZ, basisX).normalize();
    const m = new THREE.Matrix4().makeBasis(basisX, basisY, basisZ);

    // Apply rotations in local space
    // (Note: This is a simplified solver; rigs vary widely. Adjust axes if needed.)
    hip.lookAt(target);
    knee.rotation.z = -kneeAngle; // assumes z-axis as bend axis

    // Ankle alignment
    ankle.lookAt(target);
  }

  update(dt) {
  if (!this.enabled) return;
  if (!this.groundMeshes || this.groundMeshes.length === 0) return;
    const procLeg = (leg) => {
      if (!leg || !leg.hip || !leg.knee || !leg.ankle || !leg.foot) return;

      // Get ankle world pos as cast origin
      leg.ankle.updateWorldMatrix(true, false);
      const origin = leg.ankle.getWorldPosition(new THREE.Vector3());
      const tgt = this._raycastFootTarget(origin);
      this._solveTwoBone(leg.hip, leg.knee, leg.ankle, tgt);
    };

    procLeg(this.left);
    procLeg(this.right);
  }
}
