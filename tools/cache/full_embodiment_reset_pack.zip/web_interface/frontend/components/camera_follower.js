/**
 * camera_follower.js
 * Prevents the "zoom illusion" by attaching camera and controls target to the avatar rig.
 * - Keeps a fixed offset from the rig
 * - Updates controls.target (if OrbitControls present)
 * - Optional smoothing
 */

import * as THREE from 'three'

export class CameraFollower {
  constructor({ camera, controls=null, rig, offset = {x: 0, y: 1.6, z: 3.5}, smooth = 0.12 }) {
    this.camera = camera;
    this.controls = controls;
    this.rig = rig;
    this.offset = offset;
    this.smooth = smooth;
    this._v = new THREE.Vector3();
    this._t = new THREE.Vector3();
    this.enabled = true;
  }

  update(dt) {
    if (!this.enabled || !this.camera || !this.rig) return;
    this._t.set(this.offset.x, this.offset.y, this.offset.z).applyQuaternion(this.rig.quaternion).add(this.rig.position);
    // Smooth follow
    this._v.copy(this.camera.position).lerp(this._t, Math.min(1, this.smooth * (dt ? dt*60 : 1)));
    this.camera.position.copy(this._v);
    if (this.controls && this.controls.target) {
      this.controls.target.lerp(this.rig.position, Math.min(1, this.smooth * (dt ? dt*60 : 1)));
      this.controls.update?.();
    } else {
      this.camera.lookAt(this.rig.position);
    }
  }
}
