// avatar_repair.js
import * as THREE from 'three';

/** Fix common export/render issues: culling, alpha, shadows */
export function repairAvatar(root){
	root.traverse(o=>{
		if (o.isSkinnedMesh) { o.frustumCulled = false; }
		if (o.material){
			const mats = Array.isArray(o.material) ? o.material : [o.material];
			for(const m of mats){
				if (!m) continue;
				// Treat cutouts as alphaTest instead of transparent blend to avoid sorting holes
				if (m.transparent && m.opacity === 1 && !m.alphaMap) {
					m.alphaTest = 0.5; m.transparent = false;
				}
				m.depthWrite = true; m.depthTest = true;
				o.castShadow = true; o.receiveShadow = true;
			}
		}
	});
}

/** Hide common debug proxies (capsules/spheres/colliders) */
export function hideDebugPrimitives(scene){
	const suspect = /(^Collider|Capsule|Debug|Gizmo|Proxy|Helper)/i;
	const geoType = /^(SphereGeometry|CylinderGeometry|CapsuleGeometry)$/;
	let n=0;
	scene.traverse(o=>{
		if (o?.isMesh) {
			const nameHit = suspect.test(o.name||"");
			const typeHit = o.geometry && geoType.test(o.geometry.type);
			const isEye = /eye/i.test(o.name||"");
			if ((nameHit || typeHit) && !isEye) { o.visible=false; n++; }
		}
	});
	console.info('Hidden debug primitives:', n);
}
