/**
 * autopilot.js
 * Tiny autonomous director for demo/showcase: sets target speed and occasional gestures.
 */

export class Autopilot {
  constructor(opts = {}) {
    this.state = 'idle';
    this.time = 0;
    this.timer = 0;
    this.minHold = opts.minHold || 2.5;
    this.maxHold = opts.maxHold || 6.0;
    this.speed = 0; // 0..1 normalized locomotion speed
  }

  _pickNext() {
    const choices = [
      { state: 'idle', speed: 0 },
      { state: 'walk', speed: 0.35 },
      { state: 'run',  speed: 0.8 },
      { state: 'turn_left', speed: 0.25 },
      { state: 'turn_right', speed: 0.25 },
    ];
    const c = choices[Math.floor(Math.random() * choices.length)];
    this.state = c.state;
    this.speed = c.speed;
    this.timer = this.minHold + Math.random() * (this.maxHold - this.minHold);
  }

  update(dt) {
    this.time += dt;
    if (this.timer <= 0) this._pickNext();
    this.timer -= dt;

    // Occasional gestures
    const gestures = [];
    if (Math.random() < 0.02 * dt) gestures.push('wave');
    if (Math.random() < 0.015 * dt) gestures.push('point');

    return { state: this.state, speed: this.speed, gestures };
  }
}
