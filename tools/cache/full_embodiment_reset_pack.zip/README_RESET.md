# Full Embodiment Reset Pack

This reset viewer and modules avoid path drift and ensure legs/head/wings/clothes work without a bundler.

How to run
- Open: http://127.0.0.1:8000/webview/viewer_avatar_reset.html
- If no model auto-loads, click “Load GLB/GLTF…” and pick your .glb/.gltf.
- Sliders: Speed, Cadence, Step length, Step width. Toggles: Follow Cam, Wings, Repair Materials, Hide Debug.

What’s included
- web_interface/viewer_avatar_reset.html — self-contained viewer (Three.js via CDN import map)
- web_interface/frontend/components — modules: locomotion, IK (two-bone), head/eyes look, arms relax, wings, camera follower, repairs, etc.
- web_interface/frontend/components/gait_params.json

Notes
- Update order: engine.update -> mixer.update -> IK.update -> look.update -> arms.update -> wings.update -> follower.update -> render.
- Keep AnimationMixer on avatar (skinned root), not the rig. The rig only moves in world space.
